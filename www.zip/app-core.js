// ===== STATE =====
let profile = {}, meals = [], supplements = [], activities = [], currentMealType = 'desayuno', currentAnalysis = null, selectedGoals = [], selectedActivity = '', selectedFeeling = '', metrics = [];

const FOOD_DB = [
    { name: "Pollo a la plancha", emoji: "🍗", kcal: 165, prot: 31, carb: 0, fat: 3.6, score: 88, cardio: 85, meta: 82, micro: 70 },
    { name: "Arroz integral", emoji: "🍚", kcal: 112, prot: 2.6, carb: 23, fat: 0.9, score: 79, cardio: 72, meta: 78, micro: 65 },
    { name: "Huevo revuelto", emoji: "🥚", kcal: 149, prot: 10, carb: 1.6, fat: 11, score: 82, cardio: 74, meta: 81, micro: 88 },
    { name: "Avena con leche", emoji: "🥣", kcal: 158, prot: 6, carb: 27, fat: 3, score: 85, cardio: 80, meta: 76, micro: 72 },
    { name: "Ensalada César", emoji: "🥗", kcal: 120, prot: 8, carb: 6, fat: 9, score: 74, cardio: 78, meta: 70, micro: 82 },
    { name: "Salmón al horno", emoji: "🐟", kcal: 208, prot: 28, carb: 0, fat: 10, score: 92, cardio: 94, meta: 89, micro: 90 },
    { name: "Banana", emoji: "🍌", kcal: 89, prot: 1.1, carb: 23, fat: 0.3, score: 78, cardio: 76, meta: 80, micro: 65 },
    { name: "Yogur griego", emoji: "🫙", kcal: 59, prot: 10, carb: 3.6, fat: 0.4, score: 86, cardio: 81, meta: 83, micro: 75 },
    { name: "Tostada integral", emoji: "🍞", kcal: 80, prot: 3, carb: 14, fat: 1, score: 71, cardio: 68, meta: 72, micro: 60 },
    { name: "Lentejas", emoji: "🫘", kcal: 230, prot: 18, carb: 40, fat: 0.8, score: 90, cardio: 82, meta: 87, micro: 93 },
    { name: "Quinoa", emoji: "🌾", kcal: 120, prot: 4.4, carb: 21, fat: 1.9, score: 88, cardio: 79, meta: 82, micro: 80 },
    { name: "Batata asada", emoji: "🍠", kcal: 103, prot: 2.3, carb: 24, fat: 0.1, score: 83, cardio: 79, meta: 84, micro: 78 },
    { name: "Brócoli al vapor", emoji: "🥦", kcal: 31, prot: 2.5, carb: 6, fat: 0.4, score: 96, cardio: 91, meta: 90, micro: 97 },
    { name: "Pechuga de pavo", emoji: "🦃", kcal: 135, prot: 28, carb: 0, fat: 3, score: 89, cardio: 86, meta: 85, micro: 80 },
    { name: "Tofu salteado", emoji: "🥢", kcal: 144, prot: 15, carb: 3, fat: 9, score: 84, cardio: 80, meta: 79, micro: 74 },
    { name: "Garbanzos", emoji: "🫘", kcal: 164, prot: 9, carb: 27, fat: 2.6, score: 87, cardio: 83, meta: 85, micro: 82 },
    { name: "Palta", emoji: "🥑", kcal: 160, prot: 2, carb: 9, fat: 15, score: 91, cardio: 88, meta: 87, micro: 85 },
    { name: "Almendras", emoji: "🌰", kcal: 576, prot: 21, carb: 22, fat: 49, score: 88, cardio: 86, meta: 84, micro: 80 },
    { name: "Espinaca salteada", emoji: "🥬", kcal: 23, prot: 2.9, carb: 3.6, fat: 0.4, score: 95, cardio: 90, meta: 88, micro: 92 },
    { name: "Kefir", emoji: "🥛", kcal: 61, prot: 3.5, carb: 4.8, fat: 3.3, score: 88, cardio: 82, meta: 83, micro: 86 },
    { name: "Proteína whey", emoji: "💪", kcal: 120, prot: 25, carb: 3, fat: 2, score: 85, cardio: 78, meta: 83, micro: 60 },
    { name: "Pizza casera", emoji: "🍕", kcal: 266, prot: 11, carb: 33, fat: 10, score: 48, cardio: 42, meta: 50, micro: 44 },
    { name: "Medialunas", emoji: "🥐", kcal: 280, prot: 5, carb: 36, fat: 14, score: 38, cardio: 35, meta: 40, micro: 32 }
];

const MICROS_MAP = [
    { name: "Vitamina C", unit: "mg", good: 90, icon: "🍊" },
    { name: "Hierro", unit: "mg", good: 18, icon: "🔴" }, { name: "Calcio", unit: "mg", good: 1000, icon: "🦴" },
    { name: "Magnesio", unit: "mg", good: 320, icon: "💚" },
    { name: "Zinc", unit: "mg", good: 11, icon: "⚡" }, { name: "Potasio", unit: "mg", good: 2600, icon: "🫶" }
];

// ===== ONBOARDING =====
// ===== EXTENDED CLINICAL STATE =====
let selectedAllergies = [];
let selectedConditions = [];

// Carousel & Slides Logic
let currentOnbSlide = 1;
function nextSlide(n) {
    goToSlide(n);
}
function goToSlide(n) {
    document.querySelectorAll('.carousel-slide').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.carousel-dots .dot').forEach(d => d.classList.remove('active'));
    
    const slide = document.getElementById(`slide-${n}`);
    if (slide) slide.classList.add('active');
    
    const dot = document.getElementById(`dot-${n}`);
    if (dot) dot.classList.add('active');
    
    currentOnbSlide = n;
}
function goToPersonalization() {
    nextOnbStep(2);
}

// Multiple Goal Selection logic for Step 2 (max 3 selections)
function toggleGoalMultiple(el) {
    const goal = el.dataset.goal;
    const index = selectedGoals.indexOf(goal);
    
    if (index > -1) {
        // Deselect
        el.classList.remove('selected');
        selectedGoals.splice(index, 1);
    } else {
        // Select if under limit
        if (selectedGoals.length >= 3) {
            showMsg('Puedes seleccionar hasta 3 prioridades como máximo');
            return;
        }
        el.classList.add('selected');
        selectedGoals.push(goal);
    }
    
    const gc = document.getElementById('goal-counter');
    if (gc) {
        gc.textContent = `${selectedGoals.length} de 3 prioridades seleccionadas`;
    }
}
window.toggleGoalMultiple = toggleGoalMultiple;

// Pre-permissions logic
async function requestCameraPermission() {
    try {
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            await window.Capacitor.Plugins.Camera.requestPermissions();
        } else {
            // Web fallback
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            stream.getTracks().forEach(track => track.stop());
        }
        const btn = document.getElementById('btn-perm-camera');
        if (btn) {
            btn.textContent = '✓ Activo';
            btn.style.background = 'rgba(74,222,128,0.1)';
            btn.style.borderColor = 'rgba(74,222,128,0.2)';
            btn.style.color = 'var(--green)';
            btn.disabled = true;
        }
    } catch (err) {
        console.warn('Camera permission denied:', err);
        showMsg('Permiso de cámara no disponible.');
    }
}

async function requestNotificationPermission() {
    try {
        if (window.Capacitor && window.Capacitor.isNativePlatform()) {
            await window.Capacitor.Plugins.LocalNotifications.requestPermissions();
        } else {
            // Web fallback
            await Notification.requestPermission();
        }
        const btn = document.getElementById('btn-perm-notif');
        if (btn) {
            btn.textContent = '✓ Activo';
            btn.style.background = 'rgba(74,222,128,0.1)';
            btn.style.borderColor = 'rgba(74,222,128,0.2)';
            btn.style.color = 'var(--green)';
            btn.disabled = true;
        }
    } catch (err) {
        console.warn('Notification permission denied:', err);
        showMsg('Permiso de notificaciones no disponible.');
    }
}

function nextOnbStep(n) {
    document.querySelectorAll('.onb-step').forEach(s => s.classList.remove('active'));
    const stepEl = document.getElementById(`onb-step-${n}`);
    if (stepEl) stepEl.classList.add('active');

    // Handle progress bar visibility and progress calculation
    const progressContainer = document.getElementById('onb-progress-container');
    if (progressContainer) {
        if (n === 6) {
            progressContainer.classList.add('hidden');
        } else {
            progressContainer.classList.remove('hidden');
            const totalSteps = 5;
            const currentProgressStep = n;
            const percentage = Math.round((currentProgressStep / totalSteps) * 100);
            
            const progressFill = document.getElementById('onb-progress-bar-fill');
            if (progressFill) progressFill.style.width = `${percentage}%`;
            
            const progressText = document.getElementById('onb-progress-text');
            if (progressText) progressText.textContent = `Paso ${currentProgressStep} de ${totalSteps}`;
        }
    }
}

function validateStep2() {
    if (!Array.isArray(selectedGoals) || selectedGoals.length === 0) {
        showMsg('Debes elegir aunque sea una y hasta 3 prioridades para continuar');
        return;
    }
    nextOnbStep(3);
}

function validateStep3() {
    const name = document.getElementById('user-name')?.value?.trim();
    const email = document.getElementById('user-email')?.value?.trim();
    const age = +document.getElementById('user-age')?.value;
    const weight = +document.getElementById('user-weight')?.value;
    const height = +document.getElementById('user-height')?.value;

    if (!name) {
        showMsg('Por favor ingresá tu nombre');
        return;
    }
    if (!email || !email.includes('@')) {
        showMsg('Por favor ingresá un correo electrónico válido');
        return;
    }
    if (!age || age < 10 || age > 100) {
        showMsg('Por favor ingresá una edad válida');
        return;
    }
    if (!weight || weight < 30 || weight > 300) {
        showMsg('Por favor ingresá un peso válido');
        return;
    }
    if (!height || height < 100 || height > 250) {
        showMsg('Por favor ingresá una altura válida');
        return;
    }
    nextOnbStep(4);
}

function toggleClinicalItem(el, type) {
    const val = el.dataset.value;
    if (type === 'allergy') {
        if (val === 'ninguno') {
            selectedAllergies = ['ninguno'];
            document.querySelectorAll('#allergies-grid .clinical-card').forEach(card => {
                if (card.dataset.value === 'ninguno') {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
            });
            return;
        } else {
            selectedAllergies = selectedAllergies.filter(x => x !== 'ninguno');
            const noneCard = document.querySelector('#allergies-grid .clinical-card[data-value="ninguno"]');
            if (noneCard) noneCard.classList.remove('selected');
        }

        if (selectedAllergies.includes(val)) {
            selectedAllergies = selectedAllergies.filter(x => x !== val);
            el.classList.remove('selected');
        } else {
            selectedAllergies.push(val);
            el.classList.add('selected');
        }
    } else if (type === 'condition') {
        if (val === 'ninguno') {
            selectedConditions = ['ninguno'];
            document.querySelectorAll('#conditions-grid .clinical-card').forEach(card => {
                if (card.dataset.value === 'ninguno') {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
            });
            return;
        } else {
            selectedConditions = selectedConditions.filter(x => x !== 'ninguno');
            const noneCard = document.querySelector('#conditions-grid .clinical-card[data-value="ninguno"]');
            if (noneCard) noneCard.classList.remove('selected');
        }

        if (selectedConditions.includes(val)) {
            selectedConditions = selectedConditions.filter(x => x !== val);
            el.classList.remove('selected');
        } else {
            selectedConditions.push(val);
            el.classList.add('selected');
        }
    }
}

async function finishOnboarding() {
    const name = document.getElementById('user-name')?.value?.trim() || 'Usuario';
    const email = document.getElementById('user-email')?.value?.trim() || '';
    const age = +document.getElementById('user-age')?.value || 30;
    const sex = document.getElementById('user-sex')?.value || 'F';
    const weight = +document.getElementById('user-weight')?.value || 70;
    const height = +document.getElementById('user-height')?.value || 165;
    const targetWeight = +document.getElementById('user-target-weight')?.value || weight;
    const diet = document.getElementById('user-diet')?.value || 'omnivoro';
    const dislikes = document.getElementById('user-dislikes')?.value?.trim() || '';
    const activity = document.getElementById('user-activity')?.value || 'moderado';
    
    if (!email || !email.includes('@')) {
        showMsg('Por favor ingresá un correo electrónico válido');
        return;
    }

    const goalsArray = (Array.isArray(selectedGoals) && selectedGoals.length > 0) ? selectedGoals : ['saludGeneral'];
    const goal = goalsArray.join(',');
    
    const mult = { sedentario: 1.2, ligero: 1.375, moderado: 1.55, activo: 1.725, muyActivo: 1.9 };
    const bmr = sex === 'M' ? 10 * weight + 6.25 * height - 5 * age + 5 : 10 * weight + 6.25 * height - 5 * age - 161;
    const tdee = Math.round(bmr * (mult[activity] || 1.55));
    
    // Calorie adjustments based on goals and target weight differences
    const adj = { perderPeso: -500, ganarMusculo: 300, recomposicion: 0, saludGeneral: 0, longevidad: -100, energia: 100, rendimientoDeportivo: 200, saludMental: 0 };
    let calorieAdj = 0;
    goalsArray.forEach(g => {
        calorieAdj += adj[g] || 0;
    });

    // If targetWeight is less than current weight, apply a caloric deficit if not already factored in
    const weightDiff = targetWeight - weight;
    if (weightDiff < -2 && !goalsArray.includes('perderPeso')) {
        calorieAdj += -350; // Moderated caloric deficit for fat loss to reach target weight
    } else if (weightDiff > 2 && !goalsArray.includes('ganarMusculo')) {
        calorieAdj += 250; // Moderated caloric surplus for muscle/weight gain
    }

    calorieAdj = Math.max(-600, Math.min(500, calorieAdj));
    const targetCals = tdee + calorieAdj;
    
    // Protein intake adapted to goals
    let protMultiplier = 1.9;
    if (goalsArray.includes('ganarMusculo') || goalsArray.includes('rendimientoDeportivo')) {
        protMultiplier = 2.2;
    } else if (goalsArray.includes('perderPeso')) {
        protMultiplier = 2.0; // Higher protein retention during deficit
    }
    const prot = Math.round(weight * protMultiplier);
    
    const fat = Math.round(targetCals * 0.28 / 9);
    const carb = Math.round((targetCals - prot * 4 - fat * 9) / 4);

    profile = { 
        name, email, age, sex, weight, height, targetWeight, diet, goal, activity, 
        tdee, targetCals, prot, carb, fat,
        allergies: selectedAllergies, 
        conditions: selectedConditions, 
        dislikes 
    };

    // INTENTAR CREAR/GUARDAR PERFIL EN SUPABASE AUTOMÁTICAMENTE
    try {
        const response = await fetch('/api/auth/identify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, profileData: profile })
        });
        if (response.ok) {
            const data = await response.json();
            if (data.token) {
                localStorage.setItem('niaSaasToken', data.token);
            }
        }
        localStorage.setItem('niaDisclaimerLastShown', new Date().toDateString());
    } catch (e) {
        console.warn('⚠️ No se pudo registrar el perfil en la nube durante el onboarding. Operando en modo local.', e.message);
        localStorage.setItem('niaDisclaimerLastShown', new Date().toDateString());
    }

    // Show AI simulation loader
    const loadingScreen = document.getElementById('onboarding-loading');
    if (loadingScreen) {
        loadingScreen.classList.remove('hidden');
        
        // Sequence steps animation
        const steps = ['l-step-1', 'l-step-2', 'l-step-3', 'l-step-4', 'l-step-5'];
        steps.forEach((sId, index) => {
            setTimeout(() => {
                const stepEl = document.getElementById(sId);
                if (stepEl) {
                    stepEl.classList.add('active');
                    if (index > 0) {
                        const prevEl = document.getElementById(steps[index - 1]);
                        if (prevEl) {
                            prevEl.classList.remove('active');
                            prevEl.classList.add('completed');
                        }
                    }
                }
            }, index * 800);
        });

        // Finally launch application after simulation completes
        setTimeout(() => {
            const lastEl = document.getElementById(steps[steps.length - 1]);
            if (lastEl) {
                lastEl.classList.remove('active');
                lastEl.classList.add('completed');
            }
            setTimeout(() => {
                loadingScreen.classList.add('hidden');
                showOnboardingSummary();
            }, 300);
        }, steps.length * 800 + 400);
    } else {
        showOnboardingSummary();
    }
}

function niaPopulateOnboardingInputs() {
    const p = profile || {};
    const nameEl = document.getElementById('user-name');
    if (nameEl) nameEl.value = p.name || '';
    const ageEl = document.getElementById('user-age');
    if (ageEl) ageEl.value = p.age || '';
    const sexEl = document.getElementById('user-sex');
    if (sexEl) sexEl.value = p.sex || 'F';
    const weightEl = document.getElementById('user-weight');
    if (weightEl) weightEl.value = p.weight || '';
    const heightEl = document.getElementById('user-height');
    if (heightEl) heightEl.value = p.height || '';
    const targetWeightEl = document.getElementById('user-target-weight');
    if (targetWeightEl) targetWeightEl.value = p.targetWeight || p.weight || '';
    const dietEl = document.getElementById('user-diet');
    if (dietEl) dietEl.value = p.diet || 'omnivoro';
    const dislikesEl = document.getElementById('user-dislikes');
    if (dislikesEl) dislikesEl.value = p.dislikes || '';

    // Set selectedGoals and select cards
    const goalString = p.goal || 'saludGeneral';
    selectedGoals = goalString.split(',').filter(g => g.trim() !== '');
    document.querySelectorAll('.goal-card').forEach(c => {
        if (selectedGoals.includes(c.dataset.goal)) c.classList.add('selected');
        else c.classList.remove('selected');
    });
    const gc = document.getElementById('goal-counter');
    if (gc) gc.textContent = `${selectedGoals.length} de 3 prioridades seleccionadas`;

    const btn = document.getElementById('btn-validate-step-2');
    if (btn) btn.disabled = selectedGoals.length === 0;

    // Set selectedActivity and select item
    selectedActivity = p.activity || 'moderado';
    document.querySelectorAll('.activity-item').forEach(c => {
        if (c.dataset.activity === selectedActivity) c.classList.add('selected');
        else c.classList.remove('selected');
    });

    // Populate allergies selection cards
    selectedAllergies = Array.isArray(p.allergies) ? p.allergies : [];
    document.querySelectorAll('#allergies-grid .clinical-card').forEach(c => {
        if (selectedAllergies.includes(c.dataset.value)) c.classList.add('selected');
        else c.classList.remove('selected');
    });

    // Populate conditions selection cards
    selectedConditions = Array.isArray(p.conditions) ? p.conditions : [];
    document.querySelectorAll('#conditions-grid .clinical-card').forEach(c => {
        if (selectedConditions.includes(c.dataset.value)) c.classList.add('selected');
        else c.classList.remove('selected');
    });

    if (typeof niaValidateStep3Inline === 'function') {
        niaValidateStep3Inline();
    }
}

function niaEditProfileFromOnboarding(startStep = 2) {
    niaPopulateOnboardingInputs();
    const appEl = document.getElementById('app');
    if (appEl) appEl.classList.remove('active');
    const onbEl = document.getElementById('onboarding');
    if (onbEl) onbEl.classList.add('active');
    nextOnbStep(startStep);
}

// ===== INIT =====
function initApp() {
    try {
        const sp = localStorage.getItem('nutriProfile');
        profile = sp ? (JSON.parse(sp) || {}) : {};
    } catch(e) { profile = {}; }
    try {
        const sm = localStorage.getItem('nutriMeals');
        meals = sm ? (JSON.parse(sm) || []) : [];
        if (!Array.isArray(meals)) meals = [];
    } catch(e) { meals = []; }
    try {
        const ss = localStorage.getItem('nutriSupps');
        supplements = ss ? (JSON.parse(ss) || []) : [];
        if (!Array.isArray(supplements)) supplements = [];
    } catch(e) { supplements = []; }
    try {
        const sa = localStorage.getItem('nutriActivities');
        activities = sa ? (JSON.parse(sa) || []) : [];
        if (!Array.isArray(activities)) activities = [];
    } catch(e) { activities = []; }
    try {
        const savedMetrics = localStorage.getItem('nutriMetrics');
        metrics = savedMetrics ? (JSON.parse(savedMetrics) || []) : [];
        if (!Array.isArray(metrics)) metrics = [];
    } catch(e) { metrics = []; }
    
    // Update daily progress bar
    updateDailyProgressBar();
    
    document.getElementById('onboarding').classList.remove('active');
    document.getElementById('app').classList.add('active');
    updateDashboard(); updateNutricion(); updateProfile();
    if (typeof niaAttachOnboardingValidators === 'function') {
        niaAttachOnboardingValidators();
    }

    
    // Check if we need to redirect to a specific tab from onboarding or start first-time tour
    const redirectTab = localStorage.getItem('niaFinishRedirect');
    if (redirectTab) {
        localStorage.removeItem('niaFinishRedirect');
        showScreen(redirectTab);
        if (redirectTab === 'comidas') {
            niaSelectMealDay('today');
        }
        renderMealsLog();
    } else if (localStorage.getItem('niaFirstTimeTour') === 'true') {
        localStorage.removeItem('niaFirstTimeTour'); // Consume
        showScreen('home');
        renderMealsLog();
        setTimeout(() => {
            if (typeof startFastTrackTour === 'function') {
                startFastTrackTour();
            }
        }, 800);
    } else {
        showScreen('home');
        renderMealsLog();
    }
}

function startNewUserExperience(registerNow) {
    const modal = document.getElementById('new-user-welcome-modal');
    if (modal) modal.classList.add('hidden');
    
    // Ensure all tooltips and tour overlay are hidden
    const overlay = document.getElementById('onb-tour-overlay');
    if (overlay) overlay.classList.add('hidden');
    document.querySelectorAll('.onb-tooltip').forEach(t => t.classList.add('hidden'));
    window.currentTourStep = 0;
    
    showScreen('comidas');
    niaSelectMealDay('today');
}
window.startNewUserExperience = startNewUserExperience;

// ===== NAV =====
function showScreen(name) {
    if (name !== 'comidas' && typeof niaTargetMealDate !== 'undefined' && niaTargetMealDate !== null) {
        niaCancelMealsFlow();
    }
    // Map legacy screen names to consolidated screen names
    if (name === 'inicio') name = 'home';
    if (name === 'suplementos') name = 'nutricion';
    if (name === 'apps') name = 'actividad';
    if (name === 'hidratacion') {
        localStorage.setItem('niaScrollToHydration', 'true');
        name = 'comidas';
    }
    if (name === 'logros') name = 'home';
    if (name === 'progreso') name = 'home';
    if (name === 'cuerpo') name = 'nutricion';
    
    if (name === 'recetas') {
        name = 'nutricion';
        setTimeout(() => {
            if (typeof niaSwitchPlanSubtab === 'function') {
                niaSwitchPlanSubtab('recetas');
            }
        }, 50);
    }

    document.querySelectorAll('.tab-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
    const sec = document.getElementById(`tab-${name}`);
    if (sec) sec.classList.add('active');
    const btn = document.getElementById(`nav-${name}`);
    if (btn) btn.classList.add('active');
    
    if (name === 'home') {
        updateDashboard();
        if (typeof checkAchievements === 'function') checkAchievements();
        if (typeof updateHomeStatsSummary === 'function') updateHomeStatsSummary();
        if (typeof renderProgressCharts === 'function') {
            setTimeout(() => renderProgressCharts(currentPeriodDays), 100);
        }
    }
    if (name === 'comidas') {
        if (typeof renderMealsLog === 'function') renderMealsLog();
    }
    if (name === 'editar-perfil') {
        if (typeof niaInitProfileEditorDirect === 'function') {
            niaInitProfileEditorDirect();
        }
    }
    if (name === 'nutricion') {
        updateNutricion();
        if (typeof updateSupplements === 'function') updateSupplements();
        if (typeof updateBodyUI === 'function') updateBodyUI();
        if (typeof niaSwitchPlanSubtab === 'function') {
            niaSwitchPlanSubtab('resumen');
        }
    }
    if (name === 'actividad') {
        updateActivityPage();
        if (typeof renderMetricsHistory === 'function') renderMetricsHistory();
    }
    if (name === 'comidas') {
        if (typeof updateHydrationUI === 'function') updateHydrationUI();
        if (localStorage.getItem('niaScrollToHydration') === 'true') {
            localStorage.removeItem('niaScrollToHydration');
            setTimeout(() => {
                const el = document.getElementById('comidas-hydration-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
            }, 350);
        }
    }
    if (name === 'perfil') updateProfile();
    if (name === 'recetas') initRecipes();
}

// ===== DASHBOARD =====
function updateDashboard() {
    const rawName = profile.name ? profile.name.trim() : '';
    const firstName = rawName.split(' ')[0];
    const dashNameEl = document.getElementById('dash-name');
    if (dashNameEl) {
        dashNameEl.textContent = firstName ? `, ${firstName}` : '';
    }
    const av = document.getElementById('user-avatar');
    if (av) av.textContent = firstName ? firstName[0].toUpperCase() : 'N';
    const now = new Date();
    const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    const dd = document.getElementById('dash-date');
    if (dd) dd.textContent = `${dias[now.getDay()]}, ${now.getDate()} de ${meses[now.getMonth()]} ${now.getFullYear()}`;
    const today = getTodayMeals();
    const tot = calcTotals(today);
    const hasMeals = today.length > 0;
    const score = hasMeals ? calcDailyScore(tot, today) : 0;
    const sv = document.getElementById('score-value'); if (sv) sv.textContent = hasMeals ? score : '—';
    updateScoreRing(score, hasMeals);
    const cals = document.getElementById('cals-val'); if (cals) cals.textContent = tot.kcal.toLocaleString('es-AR');
    const rem = document.getElementById('cals-remaining');
    const todayActKcal = getTodayActivities().reduce((s, a) => s + (a.kcal || 0), 0);
    if (!profile.targetCals) {
        showMsg("⚠️ Falta configurar tu objetivo calórico. Por favor completá tu Perfil.");
    }
    const netTarget = (profile.targetCals || 2000) + todayActKcal;
    if (rem) rem.textContent = Math.max(0, netTarget - tot.kcal).toLocaleString('es-AR');
    const mc = document.getElementById('meals-count'); if (mc) mc.textContent = today.length;
    const ak = document.getElementById('activity-kcal-dash'); if (ak) ak.textContent = todayActKcal;
    const pg = profile.prot || 120, cg = profile.carb || 180, fg = profile.fat || 60;
    ['prot', 'carb', 'fat'].forEach(m => {
        const goal = { prot: pg, carb: cg, fat: fg }[m];
        const cur = { prot: tot.prot, carb: tot.carb, fat: tot.fat }[m];
        const gc = document.getElementById(`${m}-goal`); if (gc) gc.textContent = goal;
        const cc = document.getElementById(`${m}-cur`); if (cc) cc.textContent = Math.round(cur);
        const bar = document.getElementById(`${m}-bar`); if (bar) bar.style.width = Math.min(100, (cur / goal) * 100) + '%';
    });
    const dl = document.getElementById('dashboard-meals-list');
    const de = document.getElementById('dash-empty');
    if (dl) {
        dl.innerHTML = '';
        if (today.length === 0) {
            if (de) {
                de.style.display = 'flex';
                dl.appendChild(de);
            }
        } else {
            if (de) de.style.display = 'none';

            // Calculate calories by type
            const calsByType = { desayuno: 0, brunch: 0, almuerzo: 0, merienda: 0, cena: 0, snack: 0 };
            today.forEach(m => {
                const t = m.type || 'almuerzo';
                const calories = m.kcal || 0;
                if (calsByType[t] !== undefined) {
                    calsByType[t] += calories;
                } else if (t === 'colacion' || t === 'snack') {
                    calsByType.snack += calories;
                } else {
                    calsByType.almuerzo += calories;
                }
            });

            const totalCalsIngested = Object.values(calsByType).reduce((a, b) => a + b, 0);
            const pctByType = {};
            for (const key in calsByType) {
                pctByType[key] = totalCalsIngested > 0 ? (calsByType[key] / totalCalsIngested) * 100 : 0;
            }

            let lastAngle = 0;
            const slices = [];
            const activeTypes = [
                { key: 'desayuno', label: 'Desayuno', color: '#f59e0b' },
                { key: 'brunch', label: 'Brunch', color: '#10b981' },
                { key: 'almuerzo', label: 'Almuerzo', color: '#3b82f6' },
                { key: 'snack', label: 'Colación', color: '#f97316' },
                { key: 'merienda', label: 'Merienda', color: '#8b5cf6' },
                { key: 'cena', label: 'Cena', color: '#6366f1' }
            ];

            activeTypes.forEach(t => {
                const pct = pctByType[t.key] || 0;
                if (pct > 0) {
                    const startAngle = lastAngle;
                    const endAngle = lastAngle + (pct * 3.6);
                    slices.push(`${t.color} ${startAngle}deg ${endAngle}deg`);
                    lastAngle = endAngle;
                }
            });

            const gradientStr = slices.length > 0 ? `conic-gradient(${slices.join(', ')})` : 'rgba(255,255,255,0.05)';

            const chartHTML = `
              <div class="meal-distribution-container" style="display: flex; align-items: center; justify-content: space-around; gap: 1.5rem; padding: 1.25rem; background: rgba(255,255,255,0.02); border-radius: 16px; border: 1px solid rgba(255,255,255,0.05); width: 100%;">
                <div class="meal-pie-chart-wrap" style="position: relative; width: 120px; height: 120px; flex-shrink: 0;">
                  <div class="meal-pie-chart" style="width: 100%; height: 100%; border-radius: 50%; background: ${gradientStr};"></div>
                  <div class="meal-pie-center" style="position: absolute; top: 12px; left: 12px; width: 96px; height: 96px; border-radius: 50%; background: var(--bg); display: flex; flex-direction: column; align-items: center; justify-content: center; box-shadow: inset 0 2px 8px rgba(0,0,0,0.1);">
                    <span style="font-size: 0.65rem; color: var(--text-dim); text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Ingerido</span>
                    <span style="font-size: 1.1rem; font-weight: 800; color: var(--text);">${totalCalsIngested}</span>
                    <span style="font-size: 0.6rem; color: var(--text-dim);">kcal</span>
                  </div>
                </div>
                <div class="meal-pie-legend" style="flex-grow: 1; display: flex; flex-direction: column; gap: 0.5rem;">
                  ${activeTypes.map(t => {
                      const pct = pctByType[t.key] || 0;
                      const cals = calsByType[t.key] || 0;
                      if ((t.key === 'brunch' || t.key === 'snack') && cals === 0) return '';
                      return `
                        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.78rem;">
                          <div style="display: flex; align-items: center; gap: 6px;">
                            <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: ${t.color};"></span>
                            <span style="color: var(--text-dim);">${t.label}</span>
                          </div>
                          <div style="font-weight: 700; color: var(--text);">
                            <span>${Math.round(pct)}%</span>
                            <span style="font-size: 0.7rem; font-weight: 400; color: var(--text-dim); margin-left: 4px;">(${cals} kcal)</span>
                          </div>
                        </div>
                      `;
                  }).join('')}
                </div>
              </div>
            `;
            dl.innerHTML = chartHTML;
        }
    }
    // activity summary
    const todayActs = getTodayActivities();
    const ase = document.getElementById('act-sum-empty');
    const asl = document.getElementById('act-sum-list');
    if (todayActs.length === 0) { if (ase) ase.style.display = 'flex'; if (asl) asl.style.display = 'none'; }
    else {
        if (ase) ase.style.display = 'none';
        if (asl) { asl.style.display = 'block'; asl.innerHTML = todayActs.map(a => `<div style="display:flex;align-items:center;gap:8px;padding:4px 0;font-size:.85rem"><span>${ACTIVITY_EMOJIS[a.type] || '🏃'}</span><span style="flex:1">${ACTIVITY_NAMES[a.type] || a.type} · ${a.duration}min</span><span style="color:var(--orange);font-weight:700">${a.kcal} kcal</span></div>`).join(''); }
    }
    // Nutri tip
    if (typeof niaLoadNutriTip === 'function') {
        niaLoadNutriTip();
    }
    
    // Update Home Supplements widget (UX-P1-14)
    if (typeof renderHomeSupplementsWidget === 'function') {
        renderHomeSupplementsWidget();
    }
}

function isFoodCompliantWithDiet(foodName, diet) {
  if (!diet || diet === 'omnivoro' || diet === 'flexitariano') return true;
  
  const lower = foodName.toLowerCase();
  const animalKeywords = ['pollo', 'carne', 'vacuno', 'pescado', 'atún', 'salmon', 'salmón', 'jamón', 'jamon', 'pavo', 'cerdo', 'lomo', 'bife', 'asado', 'mariscos', 'langostinos', 'camarones', 'merluza'];
  const dairyKeywords = ['leche', 'queso', 'yogur', 'huevo', 'manteca', 'crema', 'mozzarella', 'whey'];
  
  if (diet === 'vegano' || diet === 'crudivoro') {
    const hasAnimal = animalKeywords.some(kw => lower.includes(kw));
    const hasDairy = dairyKeywords.some(kw => lower.includes(kw));
    return !hasAnimal && !hasDairy;
  }
  
  if (diet === 'vegetariano') {
    const hasAnimal = animalKeywords.some(kw => lower.includes(kw));
    return !hasAnimal;
  }
  
  if (diet === 'pescetariano') {
    const terrestrialKeywords = ['pollo', 'carne', 'vacuno', 'jamón', 'jamon', 'pavo', 'cerdo', 'lomo', 'bife', 'asado'];
    const hasTerrestrial = terrestrialKeywords.some(kw => lower.includes(kw));
    return !hasTerrestrial;
  }

  if (diet === 'sinGluten') {
    const glutenKeywords = ['trigo', 'pan', 'tostada integral', 'pizza', 'medialunas', 'avena', 'cebada', 'centeno', 'harina'];
    const hasGluten = glutenKeywords.some(kw => lower.includes(kw));
    return !hasGluten;
  }

  if (diet === 'sinLactosa') {
    const hasDairy = dairyKeywords.some(kw => lower.includes(kw));
    return !hasDairy;
  }
  
  if (diet === 'cetogenico') {
    const highCarbKeywords = ['arroz', 'avena', 'lentejas', 'garbanzos', 'batata', 'tostada', 'pizza', 'medialunas', 'banana'];
    const hasHighCarb = highCarbKeywords.some(kw => lower.includes(kw));
    return !hasHighCarb;
  }

  if (diet === 'paleo') {
    const forbiddenKeywords = ['leche', 'yogur', 'queso', 'mozzarella', 'kefir', 'whey', 'arroz', 'avena', 'tostada', 'harina', 'pizza', 'medialunas', 'lentejas', 'garbanzos', 'soja', 'tofu'];
    const hasForbidden = forbiddenKeywords.some(kw => lower.includes(kw));
    return !hasForbidden;
  }
  
  return true;
}

function getTips() {
    const diet = profile.diet || 'omnivoro';
    const isVegan = diet === 'vegano';
    const base = [
        "La vitamina C potencia hasta 6 veces la absorción de hierro no-hemo de legumbres y verduras. Sumá cítricos a tus comidas.",
        "El magnesio participa en más de 300 reacciones enzimáticas. Déficit muy frecuente: semillas de calabaza, cacao y almendras lo aportan.",
        "El timing proteico importa: distribuí proteína en 4-5 tomas diarias para maximizar la síntesis muscular (MPS).",
        "Hidratarse bien: la deshidratación del 2% ya reduce rendimiento físico y cognitivo. Orina amarillo pálido = buena hidratación.",
        isVegan 
          ? "Los probióticos de kéfir de agua, kombucha y chucrut mejoran la microbiota intestinal, base de la salud inmune y mental."
          : "Los probióticos de kéfir, yogur natural y chucrut mejoran la microbiota intestinal, base de la salud inmune y mental."
    ];
    const dietTips = {
        vegano: ["Suplementá B12 siempre (250-1000 µg/día): ningún alimento vegetal la aporta de forma confiable.", "Combiná arroz + legumbres para obtener proteína completa con todos los aminoácidos esenciales.", "El aceite de microalgas es la única fuente vegana directa de DHA y EPA (omega-3 activos)."],
        vegetariano: ["El huevo es la proteína de mayor valor biológico (VB=100) y aporta vitamina D, B12 y colina cerebral.", "El yogur griego duplica la proteína del yogur normal y aporta probióticos beneficiosos para la microbiota."],
        cetogenico: ["En cetosis, el magnesio y el sodio se excretan más. Asegurate de consumir aguacate, nueces y sal en moderación.", "El déficit de fibra es el mayor riesgo del keto: sumá verduras de hoja verde, brócoli y semillas de chía."],
        mediterraneo: ["El AOVE contiene oleocantal con efecto antiinflamatorio similar al ibuprofeno. Usalo en crudo para preservar sus polifenoles."]
    };
    return [...base, ...(dietTips[diet] || [])];
}

// ===== SCORE =====
function calcDailyScore(tot, mealList) {
    if (!profile.targetCals || mealList.length === 0) return 0;
    const cS = Math.max(0, 100 - Math.abs(tot.kcal - profile.targetCals) / profile.targetCals * 100);
    const pS = Math.min(100, (tot.prot / (profile.prot || 120)) * 100);
    const avg = mealList.length > 0 ? mealList.reduce((s, m) => s + (m.score || 70), 0) / mealList.length : 0;
    return Math.min(99, Math.round(cS * 0.3 + pS * 0.3 + avg * 0.4));
}
function updateScoreRing(score, hasMeals = true) {
    const c = document.getElementById('score-ring-circle');
    if (c) c.setAttribute('stroke-dashoffset', 314 - (hasMeals ? (score / 100) * 314 : 0));
    const bc = document.getElementById('big-score-circle');
    if (bc) bc.setAttribute('stroke-dashoffset', 439.8 - (hasMeals ? (score / 100) * 439.8 : 0));
    const bl = document.getElementById('big-score-label');
    if (bl) bl.textContent = hasMeals ? scoreLabel(score) : "Registrá tu primera comida para ver tu puntaje";
    const bv = document.getElementById('big-score-val');
    if (bv) bv.textContent = hasMeals ? score : '—';
    const ss = document.getElementById('score-status');
    if (ss) {
        ss.textContent = hasMeals ? scoreLabel(score) : "Registrá tu primera comida para ver tu puntaje";
        ss.style.textAlign = 'center';
        ss.style.maxWidth = '120px';
    }
}
function scoreLabel(s) {
    if (s >= 90) return 'Excelente 🌟'; if (s >= 80) return 'Muy bueno 🎉';
    if (s >= 70) return 'Bueno 👍'; if (s >= 55) return 'Regular 🙂'; return 'Mejorable 💡';
}
function scoreGradient(s) {
    if (s >= 80) return 'linear-gradient(135deg,#4ade80,#22d3ee)';
    if (s >= 60) return 'linear-gradient(135deg,#fb923c,#fbbf24)';
    return 'linear-gradient(135deg,#f87171,#fb923c)';
}

// ===== MEALS =====
function selectMealType(btn, type) {
    document.querySelectorAll('.meal-type-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active'); currentMealType = type;
}
function analyzeFood() {
    const fn = document.getElementById('food-search')?.value?.trim();
    if (!fn) { showMsg('Ingresá un alimento para analizar.'); return; }
    const qty = +document.getElementById('food-qty').value || 100;
    const food = FOOD_DB.find(f => f.name.toLowerCase().includes(fn.toLowerCase())) || generateFood(fn);
    showAnalysis(food, qty, fn);
}

// ===== 4-PART MEAL ANALYZER =====
function analyzeMealComponents() {
    const components = [
        { key: 'proteinas', label: 'Proteínas', emoji: '💪' },
        { key: 'vegetales', label: 'Vegetales', emoji: '🥦' },
        { key: 'hidratos',  label: 'Hidratos',  emoji: '🍚' },
        { key: 'postre',    label: 'Postre',     emoji: '🍮' }
    ];

    let totalKcal = 0, totalProt = 0, totalCarb = 0, totalFat = 0;
    let totalCardio = 0, totalMeta = 0, totalMicro = 0, totalScore = 0;
    let validCount = 0;
    let namesList = [];

    components.forEach(comp => {
        const nameEl = document.getElementById(`comp-${comp.key}-name`);
        const qtyEl  = document.getElementById(`comp-${comp.key}-qty`);
        const name = nameEl ? nameEl.value.trim() : '';
        const qty  = qtyEl  ? (+qtyEl.value || 0) : 0;
        if (!name || qty <= 0) return;

        const food = FOOD_DB.find(f => f.name.toLowerCase().includes(name.toLowerCase())) || generateFood(name);
        const factor = qty / 100;
        totalKcal  += Math.round(food.kcal  * factor);
        totalProt  += +(food.prot  * factor).toFixed(1);
        totalCarb  += +(food.carb  * factor).toFixed(1);
        totalFat   += +(food.fat   * factor).toFixed(1);
        totalCardio += food.cardio;
        totalMeta   += food.meta;
        totalMicro  += food.micro;
        totalScore  += food.score;
        validCount++;
        namesList.push(`${comp.emoji} ${name} (${qty}g)`);
    });

    if (validCount === 0) { showMsg('Ingresá al menos un componente con nombre y gramos.'); return; }

    const avgCardio = Math.round(totalCardio / validCount);
    const avgMeta   = Math.round(totalMeta   / validCount);
    const avgMicro  = Math.round(totalMicro  / validCount);
    const avgScore  = Math.round(totalScore  / validCount);

    // Build a combined food object for the analysis panel
    const combinedFood = {
        name: namesList.join(' · '),
        emoji: '🍽️',
        kcal: totalKcal, prot: totalProt, carb: totalCarb, fat: totalFat,
        score: avgScore, cardio: avgCardio, meta: avgMeta, micro: avgMicro,
        qty: 1 // weight already factored in
    };

    // Populate currentAnalysis manually (totals already calculated)
    currentAnalysis = {
        ...combinedFood, mealType: currentMealType, rawName: combinedFood.name,
        kcalTotal: totalKcal, protTotal: +totalProt.toFixed(1),
        carbTotal: +totalCarb.toFixed(1), fatTotal: +totalFat.toFixed(1)
    };

    const r = document.getElementById('analysis-result');
    r.classList.remove('hidden');
    document.getElementById('analysis-food-name').textContent = '🍽️ ' + (namesList.length > 1 ? 'Análisis combinado del plato' : namesList[0]);
    const sb = document.getElementById('food-score-badge');
    sb.textContent = avgScore; sb.style.background = scoreGradient(avgScore);

    document.getElementById('analysis-macros').innerHTML =
        `<div class="a-macro"><span class="a-macro-val" style="color:var(--green)">${currentAnalysis.protTotal}g</span><span class="a-macro-lbl">Proteínas</span></div>
         <div class="a-macro"><span class="a-macro-val" style="color:var(--cyan)">${currentAnalysis.carbTotal}g</span><span class="a-macro-lbl">Carbohidratos</span></div>
         <div class="a-macro"><span class="a-macro-val" style="color:var(--purple)">${currentAnalysis.fatTotal}g</span><span class="a-macro-lbl">Grasas</span></div>
         <div class="a-macro"><span class="a-macro-val" style="color:var(--orange)">${totalKcal}</span><span class="a-macro-lbl">kcal totales</span></div>`;

    document.getElementById('analysis-micros').innerHTML = MICROS_MAP.slice(0, 4).map(m => {
        const v = Math.round(m.good * (0.1 + Math.random() * 0.7)), p = Math.round(v / m.good * 100), ok = p >= 30;
        return `<div class="micro-row"><span>${m.icon} ${m.name}</span><span class="micro-status ${ok ? 'micro-ok' : 'micro-low'}">${ok ? '✓ OK' : '↑ Bajo'}</span></div>`;
    }).join('');

    document.getElementById('analysis-impacts').innerHTML =
        `<div class="a-impact"><div class="a-impact-icon">❤️</div><span class="a-impact-val" style="color:var(--green)">${avgCardio}</span><span class="a-impact-lbl">Cardiovascular</span></div>
         <div class="a-impact"><div class="a-impact-icon">⚡</div><span class="a-impact-val" style="color:var(--cyan)">${avgMeta}</span><span class="a-impact-lbl">Metabólico</span></div>
         <div class="a-impact"><div class="a-impact-icon">🦠</div><span class="a-impact-val" style="color:var(--purple)">${avgMicro}</span><span class="a-impact-lbl">Microbiota</span></div>`;

    document.getElementById('analysis-tip').textContent =
        avgScore >= 80 ? `💡 Plato muy equilibrado (Score ${avgScore}/100). Excelente combinación de macronutrientes. ¡Seguí así!` :
        avgScore >= 60 ? `💡 Buen plato (Score ${avgScore}/100). Podés mejorarlo aumentando la porción de vegetales o eligiendo proteínas magras.` :
        `💡 Plato con alto aporte calórico y bajo perfil de micronutrientes (Score ${avgScore}/100). Considerá sustituir algún componente por opciones más nutritivas.`;

    r.scrollIntoView({ behavior: 'smooth' });
}
function generateFood(name) {
    const s = name.length;
    return {
        name, emoji: '🍽️', kcal: 100 + (s * 7) % 200, prot: 5 + (s * 3) % 25, carb: 10 + (s * 5) % 40, fat: 2 + (s * 2) % 20,
        score: 55 + (s * 4) % 35, cardio: 50 + (s * 3) % 40, meta: 55 + (s * 4) % 35, micro: 45 + (s * 6) % 45
    };
}
function showAnalysis(food, qty, raw) {
    const f = qty / 100;
    currentAnalysis = {
        ...food, qty, mealType: currentMealType, rawName: raw,
        kcalTotal: Math.round(food.kcal * f), protTotal: +(food.prot * f).toFixed(1),
        carbTotal: +(food.carb * f).toFixed(1), fatTotal: +(food.fat * f).toFixed(1)
    };
    const r = document.getElementById('analysis-result');
    r.classList.remove('hidden');
    document.getElementById('analysis-food-name').textContent = food.emoji + ' ' + (food.name || raw);
    const sb = document.getElementById('food-score-badge');
    sb.textContent = food.score; sb.style.background = scoreGradient(food.score);
    document.getElementById('analysis-macros').innerHTML =
        `<div class="a-macro"><span class="a-macro-val" style="color:var(--green)">${currentAnalysis.protTotal}g</span><span class="a-macro-lbl">Proteínas</span></div>
     <div class="a-macro"><span class="a-macro-val" style="color:var(--cyan)">${currentAnalysis.carbTotal}g</span><span class="a-macro-lbl">Carbohidratos</span></div>
     <div class="a-macro"><span class="a-macro-val" style="color:var(--purple)">${currentAnalysis.fatTotal}g</span><span class="a-macro-lbl">Grasas</span></div>`;
    document.getElementById('analysis-micros').innerHTML = MICROS_MAP.slice(0, 4).map(m => {
        const v = Math.round(m.good * (0.1 + Math.random() * 0.7)), p = Math.round(v / m.good * 100), ok = p >= 30;
        return `<div class="micro-row"><span>${m.icon} ${m.name}</span><span class="micro-status ${ok ? 'micro-ok' : 'micro-low'}">${ok ? '✓ OK' : '↑ Bajo'}</span></div>`;
    }).join('');
    document.getElementById('analysis-impacts').innerHTML =
        `<div class="a-impact"><div class="a-impact-icon">❤️</div><span class="a-impact-val" style="color:var(--green)">${food.cardio}</span><span class="a-impact-lbl">Cardiovascular</span></div>
     <div class="a-impact"><div class="a-impact-icon">⚡</div><span class="a-impact-val" style="color:var(--cyan)">${food.meta}</span><span class="a-impact-lbl">Metabólico</span></div>
     <div class="a-impact"><div class="a-impact-icon">🦠</div><span class="a-impact-val" style="color:var(--purple)">${food.micro}</span><span class="a-impact-lbl">Microbiota</span></div>`;
    document.getElementById('analysis-tip').textContent =
        food.score >= 80 ? '💡 Excelente elección nutricional. Aporta positivamente a tu puntaje del día y cubre tus objetivos de macros.' :
            food.score >= 60 ? '💡 Buena opción. Para mejorar el puntaje, combinalo con una fuente de proteínas o vegetales de hoja verde.' :
                '💡 Consumo ocasional recomendado. Alta densidad calórica y bajo aporte de micronutrientes relativos.';
    document.getElementById('food-suggestions').innerHTML = '';
}
// ===== PHOTO ANALYSIS ENGINE =====
let niaData = {}; // stores all photo analysis state

const PA_FOODS = [
  { name:'Pollo a la plancha', emoji:'🍗', weight:180, kcal:165, prot:31, carb:0, fat:3.6 },
  { name:'Arroz blanco cocido', emoji:'🍚', weight:150, kcal:130, prot:2.7, carb:28, fat:0.3 },
  { name:'Arroz integral cocido', emoji:'🍚', weight:150, kcal:112, prot:2.6, carb:23, fat:0.9 },
  { name:'Huevo frito', emoji:'🍳', weight:60, kcal:90, prot:6, carb:0.4, fat:7 },
  { name:'Salmón al horno', emoji:'🐟', weight:150, kcal:208, prot:28, carb:0, fat:10 },
  { name:'Brócoli al vapor', emoji:'🥦', weight:120, kcal:31, prot:2.5, carb:6, fat:0.4 },
  { name:'Ensalada mixta', emoji:'🥗', weight:100, kcal:25, prot:1.5, carb:4, fat:0.3 },
  { name:'Papa cocida', emoji:'🥔', weight:150, kcal:103, prot:2.3, carb:24, fat:0.1 },
  { name:'Carne vacuna magra', emoji:'🥩', weight:150, kcal:215, prot:26, carb:0, fat:12 },
  { name:'Pasta cocida', emoji:'🍝', weight:180, kcal:220, prot:7, carb:43, fat:1.3 },
  { name:'Lentejas cocidas', emoji:'🫘', weight:150, kcal:230, prot:18, carb:40, fat:0.8 },
  { name:'Batata asada', emoji:'🍠', weight:150, kcal:103, prot:2.3, carb:24, fat:0.1 },
  { name:'Palta', emoji:'🥑', weight:80, kcal:128, prot:1.6, carb:7, fat:12 },
  { name:'Tomate', emoji:'🍅', weight:100, kcal:18, prot:0.9, carb:3.9, fat:0.2 },
  { name:'Espinaca salteada', emoji:'🥬', weight:100, kcal:23, prot:2.9, carb:3.6, fat:0.4 },
  { name:'Milanesa de pollo', emoji:'🍗', weight:150, kcal:280, prot:22, carb:15, fat:14 },
  { name:'Milanesa de carne', emoji:'🥩', weight:150, kcal:310, prot:24, carb:16, fat:16 },
  { name:'Pan integral', emoji:'🍞', weight:60, kcal:140, prot:5, carb:26, fat:2 },
  { name:'Queso fresco', emoji:'🧀', weight:50, kcal:140, prot:10, carb:0.5, fat:11 },
  { name:'Yogur griego', emoji:'🫙', weight:150, kcal:89, prot:15, carb:5.4, fat:0.6 },
  { name:'Poroto negro', emoji:'🫘', weight:150, kcal:190, prot:12, carb:36, fat:1 },
  { name:'Zanahoria cocida', emoji:'🥕', weight:100, kcal:35, prot:0.8, carb:8, fat:0.2 },
  { name:'Pechuga de pavo', emoji:'🦃', weight:150, kcal:135, prot:28, carb:0, fat:3 },
];

const PA_CONDIMENTS = {
  'sal': {kcal:0,prot:0,carb:0,fat:0},
  'aceite de oliva': {kcal:88,prot:0,carb:0,fat:10},
  'manteca': {kcal:72,prot:0.1,carb:0,fat:8},
  'azúcar': {kcal:19,prot:0,carb:5,fat:0},
  'ketchup': {kcal:18,prot:0.4,carb:4,fat:0.1},
  'mayonesa': {kcal:100,prot:0.3,carb:0.3,fat:11},
  'limón': {kcal:3,prot:0.1,carb:0.9,fat:0},
  'vinagre': {kcal:1,prot:0,carb:0.1,fat:0},
};

const PA_DRINKS = {
  'ninguna':         {label:'Ninguna',               kcalPer100:0,   prot:0, carb:0,   fat:0, alcohol:false},
  'agua':            {label:'Agua',                  kcalPer100:0,   prot:0, carb:0,   fat:0, alcohol:false},
  'agua-saborizada-regular': {label:'Agua saborizada (Regular)', kcalPer100:20, prot:0, carb:5,   fat:0, alcohol:false},
  'agua-saborizada-light':   {label:'Agua saborizada (Light)',   kcalPer100:0,  prot:0, carb:0,   fat:0, alcohol:false},
  'gaseosa-regular': {label:'Gaseosa regular',       kcalPer100:42,  prot:0, carb:10.6,fat:0, alcohol:false},
  'gaseosa-light':   {label:'Gaseosa light/zero',    kcalPer100:1,   prot:0, carb:0,   fat:0, alcohol:false},
  'jugo-natural':    {label:'Jugo de fruta natural', kcalPer100:45,  prot:0.5,carb:10, fat:0.1,alcohol:false},
  'jugo-caja':       {label:'Jugo de caja/polvo',    kcalPer100:50,  prot:0, carb:12,  fat:0, alcohol:false},
  'te-cafe-sin-azucar': {label:'Café, Mate o Té (Sin azúcar)', kcalPer100:2,  prot:0, carb:0.3, fat:0, alcohol:false},
  'te-cafe-con-azucar': {label:'Café, Mate o Té (Con azúcar)', kcalPer100:25, prot:0, carb:6,   fat:0, alcohol:false},
  'bebida-vegetal':  {label:'Bebida vegetal',        kcalPer100:30,  prot:0.5,carb:3,  fat:1.2,alcohol:false},
  'leche-vaca':      {label:'Leche (Vaca)',          kcalPer100:61,  prot:3.2,carb:4.8,fat:3.3,alcohol:false},
  'leche-vegetal':   {label:'Leche vegetal (Almendra/Soja, etc.)', kcalPer100:35, prot:1.0,carb:3.5,fat:1.5,alcohol:false},
  'cerveza':         {label:'Cerveza',               kcalPer100:43,  prot:0.3,carb:3.6,fat:0, alcohol:true},
  'vino':            {label:'Vino',                  kcalPer100:85,  prot:0.1,carb:2.6,fat:0, alcohol:true},
  'fernet':          {label:'Fernet/Aperitivo',      kcalPer100:188, prot:0, carb:16,  fat:0, alcohol:true},
  'whisky':          {label:'Whisky/Vodka/Gin',      kcalPer100:250, prot:0, carb:0,   fat:0, alcohol:true},
  'champagne':       {label:'Champagne/Espumante',   kcalPer100:76,  prot:0.1,carb:1.4,fat:0, alcohol:true},
  'otra-alcoholica': {label:'Bebida alcohólica',     kcalPer100:150, prot:0, carb:5,   fat:0, alcohol:true},
  'otra':            {label:'Otra bebida',            kcalPer100:30,  prot:0, carb:7,   fat:0, alcohol:false},
};

// ===== GEMINI VISION API =====
const GEMINI_VISION_PROMPT = `Sos un nutricionista clínico experto analizando una fotografía de un plato de comida.
Analizá SOLO lo que ves claramente en la imagen. NO inventes alimentos que no estén visibles.
Respondé ÚNICAMENTE con un objeto JSON válido, sin markdown, sin texto adicional.

Si la foto es de mala calidad, está borrosa, o no podés identificar bien los alimentos:
{"quality":"low","ingredients":[]}

Si podés identificar los alimentos, respondé con este formato:
{
  "quality": "good",
  "ingredients": [
    {
      "name": "nombre exacto del alimento en español",
      "weight_g": 150,
      "kcal_per100g": 165,
      "prot_per100g": 31.0,
      "carb_per100g": 0.0,
      "fat_per100g": 3.6,
      "emoji": "🍗",
      "confidence": "high",
      "unclear_reason": ""
    }
  ]
}

Reglas IMPORTANTES:
- Solo incluí alimentos que ves con claridad
- Estimá el peso en gramos según proporciones estándar de un plato hogareño argentino típico
- Usá valores nutricionales por 100g de tablas estándar USDA/FAO
- Nombrá cada alimento por separado (no agrupes)
- Si ves una preparación, describí sus componentes visibles
- Usá emojis representativos del alimento
- Para el campo "confidence" usá:
  * "high" si estás muy seguro del alimento (ej: brócoli, pechuga de pollo clara)
  * "medium" si probablemente es ese alimento pero hay dudas (ej: salsa oscura, carne no definida)
  * "low" si no podés identificarlo con certeza (ej: algo cubierto, color/forma ambigua)
- Para "confidence" low o medium, completá "unclear_reason" con una pregunta breve al usuario (ej: "¿Es arroz blanco o coliflor?", "¿Qué tipo de carne es?")`;

function niaParseSafeJSON(jsonText) {
  if (!jsonText) return null;
  // Eliminar comentarios de una sola línea (//...) que los modelos a veces añaden erróneamente en el JSON
  const cleaned = jsonText.replace(/\/\/.*$/gm, '');
  return JSON.parse(cleaned);
}

const NIA_GEMINI_DEFAULT_KEY = 'AQ.Ab8RN6ItiqORVmWfguoQUvre7-9sEo7xTvB7pX1ubcpuPv0RQQ';

async function callGeminiVision(base64Data, mimeType) {
  const token = localStorage.getItem('niaSaasToken');
  const prompt = GEMINI_VISION_PROMPT;
  const dateStr = niaTargetMealDate ? niaTargetMealDate.toISOString().split('T')[0] : new Date().toISOString().split('T')[0];

  try {
    const headers = { 'Content-Type': 'application/json' };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch('/api/analyze-plate', {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        base64Image: base64Data,
        mimeType: mimeType,
        prompt: prompt,
        date: dateStr
      })
    });

    if (response.ok) {
      if (typeof incrementDailyPhotosCount === 'function') {
        incrementDailyPhotosCount();
      }
      const data = await response.json();
      let analysisText = '';
      let parsedPayload = null;

      if (data.queued) {
        // BullMQ encolado: hacer polling de estado
        const jobId = data.jobId;
        let attempts = 0;
        const maxAttempts = 30; // 30 segundos máximo de espera
        
        while (attempts < maxAttempts) {
          await new Promise(resolve => setTimeout(resolve, 1000));
          attempts++;
          
          const jobResponse = await fetch(`/api/jobs/${jobId}`, {
            headers: token ? { 'Authorization': `Bearer ${token}` } : {}
          });
          
          if (jobResponse.ok) {
            const jobData = await jobResponse.json();
            if (jobData.state === 'completed') {
              const jobResult = jobData.result;
              if (jobResult) {
                if (jobResult.isMedicalDisclaimer) {
                  throw new Error(jobResult.analysisText); // Disclaimer médico detectado
                }
                analysisText = jobResult.analysisText;
                parsedPayload = jobResult.payload;
                break;
              }
            } else if (jobData.state === 'failed') {
              throw new Error('El análisis en segundo plano falló.');
            }
          }
        }
        
        if (!analysisText) {
          throw new Error('El análisis de plato tardó demasiado en responder.');
        }
      } else {
        // Fallback síncrono si Redis está caído
        if (data.result && data.result.isMedicalDisclaimer) {
          throw new Error(data.result.analysisText);
        }
        analysisText = data.result.analysisText;
        parsedPayload = data.result.payload;
      }

      return parsedPayload || {};
    } else {
      const errData = await response.json().catch(() => ({}));
      console.warn(`SaaS vision returned non-OK status: ${response.status}. Error: ${errData.error || ''}`);
    }
  } catch (err) {
    console.warn('Fallback to local direct Gemini due to server error:', err.message);
  }

  // Fallback local tradicional: llamada directa a Gemini
  const apiKey = localStorage.getItem('niaGeminiKey') || NIA_GEMINI_DEFAULT_KEY;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const body = {
    contents: [{
      parts: [
        { text: GEMINI_VISION_PROMPT },
        { inline_data: { mime_type: mimeType, data: base64Data } }
      ]
    }],
    generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
  };

  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (!resp.ok) {
    if (resp.status === 400 || resp.status === 401 || resp.status === 403) {
      localStorage.removeItem('niaGeminiKey');
    }
    throw new Error(`API error ${resp.status}`);
  }

  const resJson = await resp.json();
  const text = resJson?.candidates?.[0]?.content?.parts?.[0]?.text || '';
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    const finishReason = resJson?.candidates?.[0]?.finishReason;
    if (finishReason === 'SAFETY') {
      throw new Error('El análisis de la comida fue bloqueado por los filtros de seguridad de la IA.');
    } else if (finishReason === 'MAX_TOKENS') {
      throw new Error('La respuesta de la IA fue truncada (límite de tokens alcanzado).');
    } else if (resJson?.error) {
      throw new Error(`Error de la API: ${resJson.error.message || JSON.stringify(resJson.error)}`);
    } else {
      throw new Error(`Respuesta de la IA no contiene JSON. Texto recibido: ${text.substring(0, 150)}...`);
    }
  }
  return niaParseSafeJSON(jsonMatch[0]);
}

// Global State for new Flow
let niaTargetMealDate = null;
let niaPhotoData = null;
let niaPhotoMime = null;

function niaSelectMealDay(dayType, dateString) {
  const choiceContainer = document.getElementById('nia-meals-choice-container');
  const flowContainer = document.getElementById('nia-meals-flow-container');
  const dateLabel = document.getElementById('nia-active-date-label');
  
  const cameraBtn = document.getElementById('nia-btn-camera');
  if (dayType === 'today') {
    niaTargetMealDate = null;
    if (dateLabel) dateLabel.textContent = '📅 Registrando para hoy';
    if (cameraBtn) cameraBtn.style.display = 'flex';
  } else {
    niaTargetMealDate = new Date(dateString);
    const options = { weekday: 'long', day: 'numeric', month: 'long' };
    const formatted = niaTargetMealDate.toLocaleDateString('es-AR', options);
    if (dateLabel) dateLabel.textContent = `📅 Registrando para: ${formatted.charAt(0).toUpperCase() + formatted.slice(1)}`;
    if (cameraBtn) cameraBtn.style.display = 'none';
  }
  
  if (choiceContainer) choiceContainer.classList.add('hidden');
  if (flowContainer) flowContainer.classList.remove('hidden');
  
  // Clear any existing input states
  const contextEl = document.getElementById('photo-context');
  if (contextEl) contextEl.value = '';
  const textDesc = document.getElementById('food-text-description');
  if (textDesc) textDesc.value = '';
  niaRemovePhoto();
  
  const panel = document.getElementById('photo-analysis-panel');
  if (panel) panel.classList.add('hidden');
  const spinnerBlock = document.getElementById('nia-loading-spinner-block');
  if (spinnerBlock) spinnerBlock.classList.add('hidden');
  const reportBlock = document.getElementById('nia-final-report-block');
  if (reportBlock) reportBlock.classList.add('hidden');
  const editBlock = document.getElementById('nia-edit-ingredients-block');
  if (editBlock) editBlock.classList.add('hidden');
  const finalRep = document.getElementById('nia-final-report');
  if (finalRep) finalRep.innerHTML = '';

  renderMealsLog();
  updateNutricion();
}

function niaShowCalendarSelector() {
  const picker = document.getElementById('nia-meals-date-picker');
  const calContainer = document.getElementById('nia-meals-calendar-container');
  if (!picker || !calContainer) return;

  const today = new Date();
  const threeDaysAgo = new Date();
  threeDaysAgo.setDate(today.getDate() - 3);

  // Set picker limits in YYYY-MM-DD format (local timezone)
  const offset = today.getTimezoneOffset();
  const todayLocal = new Date(today.getTime() - (offset*60*1000));
  const threeDaysAgoLocal = new Date(threeDaysAgo.getTime() - (offset*60*1000));

  picker.max = todayLocal.toISOString().split('T')[0];
  picker.min = threeDaysAgoLocal.toISOString().split('T')[0];
  picker.value = todayLocal.toISOString().split('T')[0];

  calContainer.classList.remove('hidden');
}

function niaHideCalendarSelector() {
  const calContainer = document.getElementById('nia-meals-calendar-container');
  if (calContainer) calContainer.classList.add('hidden');
}

function niaSelectMealDayFromPicker() {
  const picker = document.getElementById('nia-meals-date-picker');
  if (!picker || !picker.value) return;

  // Selected date parsed locally to avoid timezone shifting
  const parts = picker.value.split('-');
  const selectedDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));

  const today = new Date();
  today.setHours(23, 59, 59, 999);
  
  const threeDaysAgo = new Date();
  threeDaysAgo.setHours(0, 0, 0, 0);
  threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);

  if (selectedDate.getTime() > today.getTime() || selectedDate.getTime() < threeDaysAgo.getTime()) {
    showMsg('❌ Error: Podés cargar comidas de los últimos 3 días únicamente.');
    return;
  }

  niaSelectMealDay('past', selectedDate.toISOString());
}

function niaCancelMealsFlow() {
  niaTargetMealDate = null;
  const choiceContainer = document.getElementById('nia-meals-choice-container');
  const flowContainer = document.getElementById('nia-meals-flow-container');
  if (choiceContainer) choiceContainer.classList.remove('hidden');
  if (flowContainer) flowContainer.classList.add('hidden');
  niaHideCalendarSelector();
  niaReset();
  
  renderMealsLog();
  updateDashboard();
  updateNutricion();
}
let niaUploadedPhotos = [];
let niaSelectedMealType = 'almuerzo';
let niaSelectedInvisibleIngredients = [];
let niaCustomInvisibleIngredients = '';
let niaSelectedDrink = 'ninguna';
let niaDrinkMl = 250;
let niaCustomDrink = '';
let niaAlcoholPct = 0;

function niaDragOver(e) {
  e.preventDefault();
  const zone = document.getElementById('photo-upload');
  if (zone) zone.classList.add('dragover');
}

function niaLeave(e) {
  e.preventDefault();
  const zone = document.getElementById('photo-upload');
  if (zone) zone.classList.remove('dragover');
}

function niaDrop(e) {
  e.preventDefault();
  const zone = document.getElementById('photo-upload');
  if (zone) zone.classList.remove('dragover');
  if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
    niaProcessFile(e.dataTransfer.files[0]);
  }
}

function niaHandleFileSelect(input) {
  if (input && input.files && input.files[0]) {
    niaProcessFile(input.files[0]);
  }
}

function niaHandleTextDescriptionInput() {
  niaUpdateAnalyzeButtonState();
}

function niaUpdateAnalyzeButtonState() {
  const btn = document.getElementById('photo-analyze-btn');
  const textDesc = document.getElementById('food-text-description');
  const hasPhoto = !!niaPhotoData;
  const hasText = textDesc && textDesc.value.trim().length > 0;

  if (btn) {
    if (hasPhoto || hasText) {
      btn.removeAttribute('disabled');
    } else {
      btn.setAttribute('disabled', 'true');
    }
  }
}

function niaProcessFile(file) {
  // Plan Básico check: limit to 4 food photos per day
  if (typeof isUserPremium === 'function' && !isUserPremium()) {
    if (typeof getDailyPhotosCount === 'function' && getDailyPhotosCount() >= 4) {
      if (typeof openPremiumModal === 'function') {
        const uploadZone = document.getElementById('photo-upload');
        openPremiumModal('food', uploadZone);
      } else {
        showMsg('No puedes acceder a mas de 4 análisis de fotos por día en Plan Básico');
      }
      return;
    }
  }

  if (!file.type.startsWith('image/')) {
    showMsg('Por favor, selecciona un archivo de imagen válido (JPG, PNG, WEBP).');
    return;
  }
  if (file.size > 10 * 1024 * 1024) {
    showMsg('El tamaño de la imagen supera el límite de 10MB.');
    return;
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    const dataUrl = e.target.result;
    niaPhotoData = dataUrl.split(',')[1];
    niaPhotoMime = file.type || 'image/jpeg';
    
    niaUploadedPhotos = [{ dataUrl, mimeType: niaPhotoMime }];

    const previewContainer = document.getElementById('photo-preview-container');
    const inner = document.getElementById('photo-upload-inner');

    if (previewContainer) previewContainer.classList.remove('hidden');
    if (inner) inner.style.display = 'none';

    niaRenderPhotosPreview();
    niaUpdateAnalyzeButtonState();
    
    // Auto-trigger analysis flow (UX-P1-02)
    niaStartFlow();
  };
  reader.readAsDataURL(file);
}

function niaRemovePhoto(e) {
  if (e) e.stopPropagation();

  niaPhotoData = null;
  niaPhotoMime = null;
  niaUploadedPhotos = [];

  const inputCam = document.getElementById('photo-input-camera');
  if (inputCam) inputCam.value = '';
  const inputBrowse = document.getElementById('photo-input-browse');
  if (inputBrowse) inputBrowse.value = '';

  const previewContainer = document.getElementById('photo-preview-container');
  const inner = document.getElementById('photo-upload-inner');

  if (previewContainer) {
    previewContainer.classList.add('hidden');
    previewContainer.innerHTML = `
      <img id="photo-preview-img" src="" alt="Vista previa de comida" />
      <button type="button" id="remove-photo-btn" class="remove-photo-btn" onclick="niaRemovePhoto(event)">×</button>
    `;
  }
  if (inner) inner.style.display = 'flex';

  niaUpdateAnalyzeButtonState();
}

function niaStartFlow() {
  const textDesc = document.getElementById('food-text-description');
  const hasText = textDesc && textDesc.value.trim().length > 0;
  if (!niaPhotoData && !hasText) {
    showMsg('Por favor, carga una foto o descríbela en el cuadro de texto primero.');
    return;
  }
  niaSelectedMealType = 'almuerzo';
  niaSelectedInvisibleIngredients = [];
  niaCustomInvisibleIngredients = '';
  niaSelectedDrink = 'ninguna';
  niaDrinkMl = 250;
  niaCustomDrink = '';
  niaAlcoholPct = 0;

  niaOpenMealTypeModal();
}

function niaOpenMealTypeModal() {
  const overlay = document.getElementById('nia-unclear-overlay');
  if (!overlay) return;

  overlay.innerHTML = `
    <div class="nia-unclear-modal scrollable-modal">
      <div class="nia-unclear-modal-header">
        <h3>🍽️ Paso 1: Tipo de Comida</h3>
        <p class="nia-sub">Selecciona el momento del día para esta comida</p>
      </div>
      
      <div class="nia-modal-content">
        <div class="nia-modal-type-grid">
          <div class="nia-modal-type-card ${niaSelectedMealType === 'desayuno' ? 'selected' : ''}" data-type="desayuno" onclick="niaSelectMealTypeCard(this)">
            <span class="nia-modal-type-emoji">🌅</span>
            <span class="nia-modal-type-name">Desayuno</span>
          </div>
          <div class="nia-modal-type-card ${niaSelectedMealType === 'brunch' ? 'selected' : ''}" data-type="brunch" onclick="niaSelectMealTypeCard(this)">
            <span class="nia-modal-type-emoji">🥑</span>
            <span class="nia-modal-type-name">Brunch</span>
          </div>
          <div class="nia-modal-type-card ${niaSelectedMealType === 'almuerzo' ? 'selected' : ''}" data-type="almuerzo" onclick="niaSelectMealTypeCard(this)">
            <span class="nia-modal-type-emoji">☀️</span>
            <span class="nia-modal-type-name">Almuerzo</span>
          </div>
          <div class="nia-modal-type-card ${niaSelectedMealType === 'merienda' ? 'selected' : ''}" data-type="merienda" onclick="niaSelectMealTypeCard(this)">
            <span class="nia-modal-type-emoji">🍎</span>
            <span class="nia-modal-type-name">Merienda</span>
          </div>
          <div class="nia-modal-type-card ${niaSelectedMealType === 'cena' ? 'selected' : ''}" data-type="cena" onclick="niaSelectMealTypeCard(this)">
            <span class="nia-modal-type-emoji">🌙</span>
            <span class="nia-modal-type-name">Cena</span>
          </div>
          <div class="nia-modal-type-card ${niaSelectedMealType === 'snack' ? 'selected' : ''}" data-type="snack" onclick="niaSelectMealTypeCard(this)">
            <span class="nia-modal-type-emoji">🥜</span>
            <span class="nia-modal-type-name">Colación</span>
          </div>
        </div>
      </div>

      <div class="nia-unclear-actions">
        <button class="btn-secondary" onclick="niaCloseModalFlow()">Cancelar</button>
        <button class="btn-primary" onclick="niaSubmitMealType()">Continuar →</button>
      </div>
    </div>`;

  overlay.classList.remove('hidden');
  setTimeout(() => overlay.classList.add('nia-overlay-visible'), 10);
}

function niaSelectMealTypeCard(el) {
  document.querySelectorAll('.nia-modal-type-card').forEach(card => card.classList.remove('selected'));
  el.classList.add('selected');
  niaSelectedMealType = el.getAttribute('data-type');
}

function niaSubmitMealType() {
  niaOpenInvisibleIngredientsModal();
}

function niaOpenInvisibleIngredientsModal() {
  const overlay = document.getElementById('nia-unclear-overlay');
  if (!overlay) return;

  const condimentsList = [
    { name: 'Aceite de oliva', label: '🫒 Aceite de Oliva' },
    { name: 'Aceite de girasol', label: '🌻 Aceite Común' },
    { name: 'Manteca', label: '🧈 Manteca' },
    { name: 'Sal', label: '🧂 Sal' },
    { name: 'Azúcar', label: '🍬 Azúcar' },
    { name: 'Mayonesa', label: '🧴 Mayonesa' },
    { name: 'Mostaza', label: '🌭 Mostaza' },
    { name: 'Ketchup', label: '🍅 Ketchup' },
    { name: 'Crema de leche', label: '🥛 Crema de Leche' },
    { name: 'Vinagre', label: '🍾 Vinagre' },
    { name: 'Queso rallado', label: '🧀 Queso Rallado' },
    { name: 'Salsa de soja', label: '🍶 Salsa de Soja' }
  ];

  const gridHTML = condimentsList.map(cond => {
    const isChecked = niaSelectedInvisibleIngredients.includes(cond.name);
    return `
      <label class="nia-condiment-checkbox-card ${isChecked ? 'selected' : ''}">
        <input type="checkbox" value="${cond.name}" ${isChecked ? 'checked' : ''} onclick="niaToggleCondimentCard(this)">
        <span class="condiment-name">${cond.label}</span>
      </label>`;
  }).join('');

  overlay.innerHTML = `
    <div class="nia-unclear-modal scrollable-modal">
      <div class="nia-unclear-modal-header">
        <h3>🧂 Paso 2: Ingredientes Invisibles</h3>
        <p class="nia-sub">Añade aceites, condimentos o agregados ocultos</p>
      </div>
      
      <div class="nia-modal-content">
        <p class="nia-modal-lbl">Selecciona los que usaste en la preparación:</p>
        <div class="nia-modal-condiments-grid">
          ${gridHTML}
        </div>
        
        <div class="form-group" style="margin-top:1.25rem">
          <label for="nia-custom-condiments" style="font-weight:700;font-size:0.85rem;margin-bottom:0.4rem;display:block">Otros condimentos o agregados (separados por comas):</label>
          <input type="text" id="nia-custom-condiments" class="input-field" value="${niaCustomInvisibleIngredients}" placeholder="Ej: limón, chimichurri, miel..." />
        </div>
      </div>

      <div class="nia-unclear-actions">
        <button class="btn-secondary" onclick="niaOpenMealTypeModal()">← Atrás</button>
        <button class="btn-primary" onclick="niaSubmitInvisibleIngredients()">Continuar →</button>
      </div>
    </div>`;
}

function niaToggleCondimentCard(checkbox) {
  const card = checkbox.closest('.nia-condiment-checkbox-card');
  if (card) {
    if (checkbox.checked) card.classList.add('selected');
    else card.classList.remove('selected');
  }
}

function niaSubmitInvisibleIngredients() {
  const checkboxes = document.querySelectorAll('.nia-modal-condiments-grid input[type="checkbox"]');
  niaSelectedInvisibleIngredients = [];
  checkboxes.forEach(cb => {
    if (cb.checked) niaSelectedInvisibleIngredients.push(cb.value);
  });

  const customInput = document.getElementById('nia-custom-condiments');
  niaCustomInvisibleIngredients = customInput ? customInput.value.trim() : '';

  niaOpenDrinkModal();
}

function niaOpenDrinkModal() {
  const overlay = document.getElementById('nia-unclear-overlay');
  if (!overlay) return;

  overlay.innerHTML = `
    <div class="nia-unclear-modal scrollable-modal">
      <div class="nia-unclear-modal-header">
        <h3>🥤 Paso 3: Bebida</h3>
        <p class="nia-sub">Añade la bebida consumida en esta comida</p>
      </div>
      
      <div class="nia-modal-content">
        <div class="nia-modal-drink-group">
          <div class="form-group">
            <label for="nia-drink-select" style="font-weight:700;font-size:0.85rem;margin-bottom:0.4rem;display:block">Selecciona el tipo de bebida:</label>
            <select id="nia-drink-select" class="input-field" onchange="niaUpdateDrinkModalDetails()">
              <option value="ninguna" ${niaSelectedDrink === 'ninguna' ? 'selected' : ''}>❌ Ninguna</option>
              <option value="agua" ${niaSelectedDrink === 'agua' ? 'selected' : ''}>💧 Agua</option>
              <option value="agua-saborizada-regular" ${niaSelectedDrink === 'agua-saborizada-regular' ? 'selected' : ''}>🫧 Agua saborizada (Regular)</option>
              <option value="agua-saborizada-light" ${niaSelectedDrink === 'agua-saborizada-light' ? 'selected' : ''}>🫧 Agua saborizada (Light)</option>
              <option value="gaseosa-regular" ${niaSelectedDrink === 'gaseosa-regular' ? 'selected' : ''}>🥤 Gaseosa regular (con azúcar)</option>
              <option value="gaseosa-light" ${niaSelectedDrink === 'gaseosa-light' ? 'selected' : ''}>🥤 Gaseosa light / zero</option>
              <option value="jugo-natural" ${niaSelectedDrink === 'jugo-natural' ? 'selected' : ''}>🍊 Jugo de fruta natural</option>
              <option value="jugo-caja" ${niaSelectedDrink === 'jugo-caja' ? 'selected' : ''}>🧪 Jugo de caja o polvo</option>
              <option value="te-cafe-sin-azucar" ${niaSelectedDrink === 'te-cafe-sin-azucar' ? 'selected' : ''}>☕ Café, Mate o Té (Sin azúcar)</option>
              <option value="te-cafe-con-azucar" ${niaSelectedDrink === 'te-cafe-con-azucar' ? 'selected' : ''}>☕ Café, Mate o Té (Con azúcar)</option>
              <option value="bebida-vegetal" ${niaSelectedDrink === 'bebida-vegetal' ? 'selected' : ''}>🌱 Bebida vegetal</option>
              <option value="leche-vaca" ${niaSelectedDrink === 'leche-vaca' ? 'selected' : ''}>🥛 Leche (Vaca)</option>
              <option value="leche-vegetal" ${niaSelectedDrink === 'leche-vegetal' ? 'selected' : ''}>🥛 Leche vegetal (Almendra/Soja, etc.)</option>
              <option value="cerveza" ${niaSelectedDrink === 'cerveza' ? 'selected' : ''}>🍺 Cerveza</option>
              <option value="vino" ${niaSelectedDrink === 'vino' ? 'selected' : ''}>🍷 Vino</option>
              <option value="fernet" ${niaSelectedDrink === 'fernet' ? 'selected' : ''}>🥃 Fernet</option>
              <option value="bebida-blanca" ${niaSelectedDrink === 'bebida-blanca' ? 'selected' : ''}>🍸 Whisky / Vodka / Gin</option>
              <option value="otro" ${niaSelectedDrink === 'otro' ? 'selected' : ''}>✏️ Otra bebida (describir abajo)</option>
            </select>
          </div>

          <div class="form-group ${niaSelectedDrink === 'otro' ? '' : 'hidden'}" id="nia-custom-drink-wrapper">
            <label for="nia-custom-drink-input" style="font-weight:700;font-size:0.85rem;margin-bottom:0.4rem;display:block">Nombre de la bebida:</label>
            <input type="text" id="nia-custom-drink-input" class="input-field" value="${niaCustomDrink}" placeholder="Ej: Licuado de frutilla, Fernet Cola..." />
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="nia-drink-ml-input" style="font-weight:700;font-size:0.85rem;margin-bottom:0.4rem;display:block">Cantidad (cm³ / ml):</label>
              <input type="number" id="nia-drink-ml-input" class="input-field" value="${niaDrinkMl}" placeholder="250" min="0" max="3000" />
            </div>
            
            <div class="form-group ${['cerveza','vino','fernet','bebida-blanca','otro'].includes(niaSelectedDrink) ? '' : 'hidden'}" id="nia-drink-alcohol-wrapper">
              <label for="nia-drink-alcohol-input" style="font-weight:700;font-size:0.85rem;margin-bottom:0.4rem;display:block">Graduación (% vol):</label>
              <input type="number" id="nia-drink-alcohol-input" class="input-field" value="${niaAlcoholPct}" placeholder="5" min="0" max="100" step="0.1" />
            </div>
          </div>
        </div>
      </div>

      <div class="nia-unclear-actions">
        <button class="btn-secondary" onclick="niaOpenInvisibleIngredientsModal()">← Atrás</button>
        <button class="btn-primary" onclick="niaSubmitDrinkAndRun()">Analizar plato con IA →</button>
      </div>
    </div>`;
}

function niaUpdateDrinkModalDetails() {
  const select = document.getElementById('nia-drink-select');
  if (!select) return;
  const val = select.value;
  niaSelectedDrink = val;

  const customWrapper = document.getElementById('nia-custom-drink-wrapper');
  const alcoholWrapper = document.getElementById('nia-drink-alcohol-wrapper');
  const alcoholInput = document.getElementById('nia-drink-alcohol-input');

  if (customWrapper) {
    if (val === 'otro') customWrapper.classList.remove('hidden');
    else customWrapper.classList.add('hidden');
  }

  if (alcoholWrapper) {
    if (['cerveza', 'vino', 'fernet', 'bebida-blanca', 'otro'].includes(val)) {
      alcoholWrapper.classList.remove('hidden');
      if (alcoholInput) {
        if (val === 'cerveza') alcoholInput.value = 5;
        else if (val === 'vino') alcoholInput.value = 13;
        else if (val === 'fernet') alcoholInput.value = 39;
        else if (val === 'bebida-blanca') alcoholInput.value = 40;
        else if (val === 'otro') alcoholInput.value = 0;
      }
    } else {
      alcoholWrapper.classList.add('hidden');
    }
  }
}

function niaSubmitDrinkAndRun() {
  const select = document.getElementById('nia-drink-select');
  niaSelectedDrink = select ? select.value : 'ninguna';

  const customInput = document.getElementById('nia-custom-drink-input');
  niaCustomDrink = customInput ? customInput.value.trim() : '';

  const mlInput = document.getElementById('nia-drink-ml-input');
  niaDrinkMl = mlInput ? (+mlInput.value || 0) : 0;

  const alcoholInput = document.getElementById('nia-drink-alcohol-input');
  niaAlcoholPct = alcoholInput ? (+alcoholInput.value || 0) : 0;

  niaCloseModalFlow();
  niaRunVisionDetection();
}

function niaCloseModalFlow() {
  const overlay = document.getElementById('nia-unclear-overlay');
  if (overlay) {
    overlay.classList.remove('nia-overlay-visible');
    setTimeout(() => overlay.classList.add('hidden'), 300);
  }
}

async function niaRunVisionDetection() {
  const panel = document.getElementById('photo-analysis-panel');
  const spinnerBlock = document.getElementById('nia-loading-spinner-block');
  const loadingText = document.getElementById('nia-loading-text');
  const editBlock = document.getElementById('nia-edit-ingredients-block');
  const reportBlock = document.getElementById('nia-final-report-block');
  const mainBtn = document.getElementById('photo-analyze-btn');

  if (panel) panel.classList.remove('hidden');
  if (spinnerBlock) spinnerBlock.classList.remove('hidden');

  const hasPhoto = !!niaPhotoData;
  const textDescValue = document.getElementById('food-text-description')?.value.trim() || '';

  if (loadingText) {
    loadingText.textContent = hasPhoto 
      ? 'La IA está detectando los ingredientes de tu foto...' 
      : 'La IA está analizando la descripción de tu plato...';
  }

  if (editBlock) editBlock.classList.add('hidden');
  if (reportBlock) reportBlock.classList.add('hidden');
  if (mainBtn) mainBtn.setAttribute('disabled', 'true');

  setTimeout(() => panel.scrollIntoView({ behavior: 'smooth' }), 200);

  let prompt = '';
  let parts = [];

  if (hasPhoto) {
    prompt = `Sos un nutricionista clínico experto analizando una fotografía de un plato de comida.
Identificá los alimentos y componentes visibles en la imagen.
Estimá el peso en gramos (weight_g) de cada ingrediente del plato principal según proporciones de un plato argentino hogareño típico.

Respondé ÚNICAMENTE con un objeto JSON válido con el siguiente formato, sin bloques de código markdown, sin texto adicional:
{
  "quality": "good", // o "low" si la imagen no tiene relación con comida o está muy borrosa
  "ingredients": [
    {
      "name": "nombre del ingrediente en español",
      "weight_g": 150,
      "emoji": "🥩"
    }
  ]
}`;
    parts.push({ text: prompt });
    parts.push({ inline_data: { mime_type: niaPhotoMime, data: niaPhotoData } });
  } else {
    prompt = `Sos un nutricionista clínico experto. El usuario no ha subido una fotografía de su comida, sino que ha proporcionado la siguiente descripción de su plato:
"${textDescValue}"

Identificá los alimentos y componentes descritos en el texto anterior.
Estimá el peso en gramos (weight_g) de cada ingrediente del plato principal basándote en la descripción y en las proporciones de un plato argentino hogareño típico. Si el usuario especificó una cantidad en gramos para el plato o ingredientes, usala como base.

Respondé ÚNICAMENTE con un objeto JSON válido con el siguiente formato, sin bloques de código markdown, sin texto adicional:
{
  "quality": "good", // o "low" si la descripción no tiene sentido o no describe comida
  "ingredients": [
    {
      "name": "nombre del ingrediente en español",
      "weight_g": 150,
      "emoji": "🍽️" // usa un emoji representativo del alimento
    }
  ]
}`;
    parts.push({ text: prompt });
  }

  try {
    let text = '';
    let apiData = null;
    try {
      // 1. Intentar llamar al backend local con el fallback a OpenAI activo
      const resp = await fetch('/api/ai-completion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt,
          base64Image: hasPhoto ? niaPhotoData : null,
          mimeType: hasPhoto ? niaPhotoMime : null
        })
      });

      if (resp.ok) {
        apiData = await resp.json();
        text = apiData.text || '';
      } else {
        throw new Error(`Backend status: ${resp.status}`);
      }
    } catch (backendErr) {
      console.warn('⚠️ Conexión local fallida. Usando llamada directa a Google Gemini API...', backendErr.message);
      
      // 2. Fallback a llamada directa cliente-servidor a Google Gemini API
      const apiKey = localStorage.getItem('niaGeminiKey') || NIA_GEMINI_DEFAULT_KEY;
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
      
      const body = {
        contents: [{ parts: parts }],
        generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
      };

      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (!resp.ok) {
        if (resp.status === 400 || resp.status === 401 || resp.status === 403) {
          localStorage.removeItem('niaGeminiKey');
        }
        throw new Error(`API error ${resp.status}`);
      }

      apiData = await resp.json();
      text = apiData?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    }
    
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      const finishReason = apiData?.candidates?.[0]?.finishReason;
      if (finishReason === 'SAFETY') {
        throw new Error('El análisis de la comida fue bloqueado por los filtros de seguridad de la IA.');
      } else if (finishReason === 'MAX_TOKENS') {
        throw new Error('La respuesta de la IA fue truncada (límite de tokens alcanzado).');
      } else if (apiData?.error) {
        throw new Error(`Error de la API: ${apiData.error.message || JSON.stringify(apiData.error)}`);
      } else {
        throw new Error(`Respuesta de la IA no contiene JSON. Texto recibido: ${text.substring(0, 150)}...`);
      }
    }
    const result = niaParseSafeJSON(jsonMatch[0]);

    if (result.quality === 'low' || !result.ingredients || result.ingredients.length === 0) {
      showMsg('⚠️ La IA no pudo identificar alimentos. Mostrando entrada manual.');
      renderPaManualEntry(true);
      if (spinnerBlock) spinnerBlock.classList.add('hidden');
      return;
    }

    if (hasPhoto && typeof incrementDailyPhotosCount === 'function') {
      incrementDailyPhotosCount();
    }

    renderPaIngredientsEditor(result.ingredients);

  } catch (err) {
    console.error('Vision detection error:', err);
    showMsg('Error en la detección: ' + err.message);
    renderPaManualEntry(false, err.message || err);
    if (spinnerBlock) spinnerBlock.classList.add('hidden');
  } finally {
    if (mainBtn) niaUpdateAnalyzeButtonState();
  }
}

function renderPaIngredientsEditor(ingredients) {
  const spinnerBlock = document.getElementById('nia-loading-spinner-block');
  const editBlock = document.getElementById('nia-edit-ingredients-block');
  const container = document.getElementById('nia-edit-list-container');
  
  if (spinnerBlock) spinnerBlock.classList.add('hidden');
  if (editBlock) editBlock.classList.remove('hidden');
  if (!container) return;

  // Check diet compatibility
  const userDiet = profile.diet || 'omnivoro';
  const nonCompliant = ingredients.filter(item => !isFoodCompliantWithDiet(item.name, userDiet));
  
  // Remove existing warning if any
  const existingWarning = document.getElementById('nia-diet-warning-editor');
  if (existingWarning) existingWarning.remove();

  if (nonCompliant.length > 0) {
    const warningDiv = document.createElement('div');
    warningDiv.id = 'nia-diet-warning-editor';
    warningDiv.style.cssText = 'padding: 12px; border-radius: 10px; background: rgba(239, 83, 80, 0.12); border: 1px solid rgba(239, 83, 80, 0.25); color: #ef5350; font-size: 0.8rem; font-weight: 600; margin-bottom: 1rem; line-height: 1.45;';
    const names = nonCompliant.map(item => `"${item.name}"`).join(', ');
    warningDiv.innerHTML = `⚠️ **Alerta de Dieta (${userDiet.charAt(0).toUpperCase() + userDiet.slice(1)}):** Detectamos alimentos no recomendados para tu perfil: ${names}. Podés editarlos o eliminarlos antes de continuar.`;
    container.parentNode.insertBefore(warningDiv, container);
  }

  container.innerHTML = '';
  ingredients.forEach(item => {
    container.appendChild(niaCreateEditIngredientRowHTML(item.name, item.weight_g, item.emoji));
  });

  // Scroll smoothly to immediately below the photo upload card (top of edit block)
  setTimeout(() => {
    if (editBlock) {
      editBlock.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, 150);
}

function niaCreateEditIngredientRowHTML(name, weight, emoji) {
  const row = document.createElement('div');
  row.className = 'nia-edit-row';
  row.style.cssText = 'display:flex; align-items:center; gap:8px';
  row.innerHTML = `
    <span class="nia-edit-emoji" style="font-size:1.1rem; flex-shrink:0">${emoji || '🍽️'}</span>
    <input type="text" class="input-field nia-edit-name" value="${name}" placeholder="Nombre del ingrediente" style="flex-grow:2; font-size:0.85rem; padding:8px 10px; margin:0" />
    <input type="number" class="input-field nia-edit-weight" value="${weight}" placeholder="Gramos" style="width:75px; font-size:0.85rem; padding:8px 10px; margin:0" />
    <span style="font-size:0.8rem; color:var(--text-dim)">g</span>
    <button type="button" class="btn-icon" onclick="this.closest('.nia-edit-row').remove()" style="color:#ef5350; font-size:1.1rem; padding:4px 8px; border:none; background:none; cursor:pointer">🗑</button>
  `;
  return row;
}

function niaAddEditIngredientRow() {
  const container = document.getElementById('nia-edit-list-container');
  if (container) {
    container.appendChild(niaCreateEditIngredientRowHTML('', 150, '🍽️'));
  }
}

async function niaSubmitConfirmedIngredients() {
  const rows = document.querySelectorAll('.nia-edit-row');
  const confirmedIngredients = [];

  rows.forEach(row => {
    const name = row.querySelector('.nia-edit-name')?.value.trim();
    const weight = +row.querySelector('.nia-edit-weight')?.value || 0;
    const emoji = row.querySelector('.nia-edit-emoji')?.textContent || '🍽️';
    if (name && weight > 0) {
      confirmedIngredients.push({ name, weight_g: weight, emoji });
    }
  });

  if (confirmedIngredients.length === 0) {
    showMsg('Por favor, ingresa al menos un ingrediente válido con sus gramos.');
    return;
  }

  const editBlock = document.getElementById('nia-edit-ingredients-block');
  const spinnerBlock = document.getElementById('nia-loading-spinner-block');
  const loadingText = document.getElementById('nia-loading-text');

  if (editBlock) editBlock.classList.add('hidden');
  if (spinnerBlock) spinnerBlock.classList.remove('hidden');
  if (loadingText) loadingText.textContent = 'La IA está calculando la composición nutricional completa y valoración...';

  await niaRunFinalNutritionAnalysis(confirmedIngredients);
}
async function niaRunFinalNutritionAnalysis(confirmedIngredients) {
  const spinnerBlock = document.getElementById('nia-loading-spinner-block');
  const reportBlock = document.getElementById('nia-final-report-block');
  const mainBtn = document.getElementById('photo-analyze-btn');

  let drinkInfoStr = 'Ninguna';
  const invisibleIngredientsStr = niaSelectedInvisibleIngredients.join(', ') + 
    (niaCustomInvisibleIngredients ? `, ${niaCustomInvisibleIngredients}` : '');
  
  if (niaSelectedDrink !== 'ninguna') {
    const drinkLabel = niaSelectedDrink === 'otro' ? niaCustomDrink : (PA_DRINKS[niaSelectedDrink]?.label || niaSelectedDrink);
    drinkInfoStr = `${drinkLabel} (${niaDrinkMl} ml${niaAlcoholPct > 0 ? `, alcohol ${niaAlcoholPct}% vol` : ''})`;
  }

  const userGoal = profile.goal || 'saludGeneral';
  const userDiet = profile.diet || 'omnivoro';
  
  // Format clinical profile variables for injection in system instructions
  const userAllergies = Array.isArray(profile.allergies) && profile.allergies.length > 0
    ? profile.allergies.map(a => {
        const labels = { gluten: 'Gluten / Celíaquía', lactosa: 'Lactosa / Lácteos', frutosSecos: 'Frutos secos / Maní', huevo: 'Huevo', pescadoMarisco: 'Pescado / Mariscos', soja: 'Soja' };
        return labels[a] || a;
      }).join(', ')
    : 'Ninguna';

  const userConditions = Array.isArray(profile.conditions) && profile.conditions.length > 0
    ? profile.conditions.map(c => {
        const labels = { diabetes: 'Diabetes', hipertension: 'Hipertensión', colesterol: 'Colesterol alto', hipotiroidismo: 'Hipotiroidismo', colonIrritable: 'SIBO', gastritis: 'Gastritis / Reflujo' };
        return labels[c] || c;
      }).join(', ')
    : 'Ninguna';

  const userDislikes = profile.dislikes || 'Ninguno';
  const hasPhoto = !!niaPhotoData;
  const textDescValue = document.getElementById('food-text-description')?.value.trim() || '';

  const prompt = `Sos un nutricionista clínico argentino experto.
Debés realizar una valoración clínica y desglose nutricional completo de una comida.
${hasPhoto 
  ? 'Recibís una fotografía del plato para contexto visual del método de preparación, junto con la lista final confirmada de componentes de la comida.' 
  : `El usuario no ha subido una fotografía, sino que describió su comida de la siguiente manera:
"${textDescValue}"
Debes usar esa descripción y la lista final confirmada de componentes de la comida para el análisis.`
}

PERFIL CLÍNICO DEL USUARIO A QUIEN VA DIRIGIDO EL PLAN:
- Tipo de alimentación: ${userDiet}
- Objetivos: ${userGoal}
- Alergias o Intolerancias alimentarias: ${userAllergies}
- Condiciones médicas / Patologías: ${userConditions}
- Alimentos excluidos por el usuario: ${userDislikes}

COMPONENTES CONFIRMADOS POR EL USUARIO:
- Plato principal (ingredientes y gramos):
${confirmedIngredients.map(i => `  * ${i.name}: ${i.weight_g}g`).join('\n')}
- Condimentos/ingredientes invisibles: "${invisibleIngredientsStr || 'Ninguno'}"
- Bebida y cantidad: "${drinkInfoStr}"
- Tipo de comida: "${niaSelectedMealType}"

INSTRUCCIONES DE ANÁLISIS:
1. Incorporá cada uno de los ingredientes del plato principal con sus gramos exactos confirmados por el usuario.
2. Incorporá los condimentos e ingredientes invisibles reportados. Estimá cantidades razonables para ellos si no se especifican (ej: 10g para aceite, 2g para sal, etc.).
3. Incorporá la bebida reportada por el usuario con su cantidad exacta.
4. Calculá las calorías (kcal_per100g) y macronutrientes (prot_per100g, carb_per100g, fat_per100g) por cada 100g de cada elemento basándote en bases de datos científicas de nutrición (USDA, FAO). Para bebidas alcohólicas, sumá el aporte de alcohol (~7 kcal por gramo puro).
5. Escribí una valoración clínica personalizada en español (clinical_assessment) enfocada en el tipo de alimentación, las condiciones de salud y los objetivos del usuario. REGLAS DE VALORACIÓN CRÍTICAS:
   - NO menciones uno por uno los objetivos específicos del perfil del usuario (tales como ganar músculo, etc.) ni nombres explícitamente sus enfermedades a menos que sea para una advertencia de riesgo. En general, debés referirte a los objetivos de forma general como "según tus objetivos".
   - La valoración clínica debe estar muy resumida, directa al grano y no debe superar las 100 palabras de longitud en total.
   - Comentá la calidad del plato completo, el impacto de los condimentos y la bebida de forma constructiva.
6. REGLA ESTRICTA DE SEGURIDAD CLÍNICA (ALERGIAS, CONDICIONES Y EXCLUSIONES):
   - Si detectás algún ingrediente que no sea apto para la dieta "${userDiet}", o que contenga alérgenos declarados por el usuario (${userAllergies}), o que represente un riesgo clínico directo para sus patologías (${userConditions}, por ejemplo sodio elevado en hipertensión, azúcares rápidos altos en diabetes, grasas saturadas excesivas en colesterol alto, irritantes en colon irritable o gastritis), o si contiene algún ingrediente de la lista de exclusiones (${userDislikes}):
     Debés incluir una advertencia médica muy visible y corta al principio de la valoración clínica (ej: "⚠️ ADVERTENCIA: [Riesgo detectado y recomendación]"), explicando de forma precisa y firme por qué infringe su salud y sugiriendo un reemplazo seguro. Esta advertencia cuenta para el límite de las 100 palabras.
   - Si no detectás ninguna contraindicación, realiza la valoración habitual alineada a su perfil.

REGLA DE REDACCIÓN CRÍTICA:
NO te presentes (no digas "¡Hola! Como nutricionista...", ni saludos similares). Comenzá directamente con el análisis y valoración clínica del plato en su conjunto de forma objetiva y constructiva.

Respondé ÚNICAMENTE con un objeto JSON válido, sin bloques de código markdown, sin texto adicional:
{
  "quality": "good",
  "clinical_assessment": "...",
  "ingredients": [
    {
      "name": "nombre del alimento o ingrediente en español",
      "weight_g": 150,
      "kcal_per100g": 165,
      "prot_per100g": 31.0,
      "carb_per100g": 0.0,
      "fat_per100g": 3.6,
      "emoji": "🍗",
      "category": "plate" // "plate", "condiment", o "drink"
    }
  ]
}`;

  try {
    let text = '';
    let apiData = null;
    try {
      // 1. Intentar llamar al backend local con el fallback a OpenAI activo
      const resp = await fetch('/api/ai-completion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt,
          base64Image: hasPhoto ? niaPhotoData : null,
          mimeType: hasPhoto ? niaPhotoMime : null
        })
      });

      if (resp.ok) {
        apiData = await resp.json();
        text = apiData.text || '';
      } else {
        throw new Error(`Backend status: ${resp.status}`);
      }
    } catch (backendErr) {
      console.warn('⚠️ Conexión local fallida. Usando llamada directa a Google Gemini API...', backendErr.message);

      // 2. Fallback a llamada directa cliente-servidor a Google Gemini API
      const apiKey = localStorage.getItem('niaGeminiKey') || NIA_GEMINI_DEFAULT_KEY;
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
      
      const body = {
        contents: [{
          parts: hasPhoto 
            ? [
                { text: prompt },
                { inline_data: { mime_type: niaPhotoMime, data: niaPhotoData } }
              ]
            : [
                { text: prompt }
              ]
        }],
        generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
      };

      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (!resp.ok) {
        if (resp.status === 400 || resp.status === 401 || resp.status === 403) {
          localStorage.removeItem('niaGeminiKey');
        }
        throw new Error(`API error ${resp.status}`);
      }

      apiData = await resp.json();
      text = apiData?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    }
    
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      const finishReason = apiData?.candidates?.[0]?.finishReason;
      if (finishReason === 'SAFETY') {
        throw new Error('El análisis de la comida fue bloqueado por los filtros de seguridad de la IA.');
      } else if (finishReason === 'MAX_TOKENS') {
        throw new Error('La respuesta de la IA fue truncada (límite de tokens alcanzado).');
      } else if (apiData?.error) {
        throw new Error(`Error de la API: ${apiData.error.message || JSON.stringify(apiData.error)}`);
      } else {
        throw new Error(`Respuesta de la IA no contiene JSON. Texto recibido: ${text.substring(0, 150)}...`);
      }
    }
    const result = niaParseSafeJSON(jsonMatch[0]);

    if (result.quality === 'low' || !result.ingredients || result.ingredients.length === 0) {
      showMsg('⚠️ La IA no pudo identificar alimentos en esta foto. Mostrando entrada manual.');
      renderPaManualEntry(true);
      if (spinnerBlock) spinnerBlock.classList.add('hidden');
      return;
    }

    niaData = {
      detected: result.ingredients.filter(i => i.category === 'plate' || !i.category),
      condiments: result.ingredients.filter(i => i.category === 'condiment'),
      drink: result.ingredients.filter(i => i.category === 'drink'),
      clinicalAssessment: result.clinical_assessment || '',
      mealType: niaSelectedMealType
    };

    let plateKcal = 0, plateProt = 0, plateCarb = 0, plateFat = 0;
    let condKcal = 0, condProt = 0, condCarb = 0, condFat = 0;
    let drinkKcal = 0, drinkProt = 0, drinkCarb = 0, drinkFat = 0;

    niaData.detected.forEach(item => {
      const fac = item.weight_g / 100;
      plateKcal += Math.round((item.kcal_per100g || 0) * fac);
      plateProt += (item.prot_per100g || 0) * fac;
      plateCarb += (item.carb_per100g || 0) * fac;
      plateFat  += (item.fat_per100g || 0) * fac;
    });

    niaData.condiments.forEach(item => {
      const fac = item.weight_g / 100;
      condKcal += Math.round((item.kcal_per100g || 0) * fac);
      condProt += (item.prot_per100g || 0) * fac;
      condCarb += (item.carb_per100g || 0) * fac;
      condFat  += (item.fat_per100g || 0) * fac;
    });

    niaData.drink.forEach(item => {
      const fac = item.weight_g / 100;
      drinkKcal += Math.round((item.kcal_per100g || 0) * fac);
      drinkProt += (item.prot_per100g || 0) * fac;
      drinkCarb += (item.carb_per100g || 0) * fac;
      drinkFat  += (item.fat_per100g || 0) * fac;
    });

    niaData.baseTotals = { kcal: plateKcal, prot: plateProt, carb: plateCarb, fat: plateFat };
    niaData.condTotals = { kcal: condKcal, prot: condProt, carb: condCarb, fat: condFat };
    niaData.drinkTotals = { kcal: drinkKcal, prot: drinkProt, carb: drinkCarb, fat: drinkFat };

    niaData.finalKcal = Math.round(plateKcal + condKcal + drinkKcal);
    niaData.finalProt = +(plateProt + condProt + drinkProt).toFixed(1);
    niaData.finalCarb = +(plateCarb + condCarb + drinkCarb).toFixed(1);
    niaData.finalFat  = +(plateFat + condFat + drinkFat).toFixed(1);

    const targetCals = profile.targetCals || 2000;
    const mealPct = Math.round(niaData.finalKcal / targetCals * 100);
    const macroTotal = niaData.finalProt + niaData.finalCarb + niaData.finalFat;
    const protRatio  = macroTotal > 0 ? (niaData.finalProt / macroTotal * 100) : 20;
    const carbRatio  = macroTotal > 0 ? (niaData.finalCarb / macroTotal * 100) : 50;
    const fatRatio   = macroTotal > 0 ? (niaData.finalFat  / macroTotal * 100) : 30;

    const score = Math.min(98, Math.max(20,
      75
      - Math.abs(mealPct - 30) * 0.7
      + Math.min(15, protRatio * 0.35)
      - Math.max(0, carbRatio - 60) * 0.3
      - Math.max(0, fatRatio - 40) * 0.3
    ));
    niaData.score = Math.round(score);

    renderPaFinalReportNew();
    niaAddToLog();

    if (spinnerBlock) spinnerBlock.classList.add('hidden');
    if (reportBlock) reportBlock.classList.remove('hidden');

    // Scroll smoothly to align the Clinical Assessment (Valoración Nutricional) card at the top
    setTimeout(() => {
      document.querySelector('.nia-assessment')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 150);

  } catch (err) {
    console.error('Final assessment error:', err);
    showMsg('Error en el análisis final: ' + err.message);
    renderPaManualEntry(false, err.message || err);
    if (spinnerBlock) spinnerBlock.classList.add('hidden');
  } finally {
    if (mainBtn) mainBtn.removeAttribute('disabled');
  }
}

function renderPaFinalReportNew() {
  const scoreInt = niaData.score;
  const totalKcal = niaData.finalKcal;
  const totalProt = niaData.finalProt;
  const totalCarb = niaData.finalCarb;
  const totalFat  = niaData.finalFat;

  const targetCals = profile.targetCals || 2000;
  const mealPct = Math.round(totalKcal / targetCals * 100);
  const macroTotal = totalProt + totalCarb + totalFat;
  const protRatio  = macroTotal > 0 ? (totalProt / macroTotal * 100) : 20;
  const carbRatio  = macroTotal > 0 ? (totalCarb / macroTotal * 100) : 50;
  const fatRatio   = macroTotal > 0 ? (totalFat  / macroTotal * 100) : 30;

  const trafficLight = scoreInt >= 75 ? '🟢' : scoreInt >= 55 ? '🟡' : '🔴';
  const trafficLabel = scoreInt >= 75 ? 'Excelente elección nutricional' : scoreInt >= 55 ? 'Aceptable — con margen de mejora' : 'Atención nutricional requerida';

  const macroBarProt = Math.min(100, Math.round(protRatio));
  const macroBarCarb = Math.min(100, Math.round(carbRatio));
  const macroBarFat  = Math.min(100, Math.round(fatRatio));

  const userDiet = profile.diet || 'omnivoro';
  const suggestions = [];
  if (totalProt < 15) {
    let protRecs = 'pollo, huevo, legumbres o pescado';
    if (userDiet === 'vegano') protRecs = 'tofu, tempeh, seitán o legumbres';
    else if (userDiet === 'vegetariano') protRecs = 'legumbres, huevos, queso magro, tofu o seitán';
    else if (userDiet === 'pescetariano') protRecs = 'pescado, mariscos, legumbres o huevos';
    suggestions.push(`📌 <strong>Proteína baja:</strong> Incorporá ${protRecs} en el plato.`);
  }
  if (totalCarb > 90) suggestions.push('📌 <strong>Carbohidratos elevados:</strong> Priorizá fuentes integrales y controlá las porciones.');
  if (totalFat > 40) suggestions.push('📌 <strong>Grasas elevadas:</strong> Revisá el método de cocción y los aderezos.');
  if (mealPct > 55) suggestions.push(`📌 <strong>Comida calórica:</strong> Representa el ${mealPct}% de tu meta diaria — ajustá el resto del día.`);
  
  let alcoholNote = '';
  niaData.drink.forEach(item => {
    if (item.name.toLowerCase().includes('cerveza') || item.name.toLowerCase().includes('vino') || item.name.toLowerCase().includes('fernet') || item.name.toLowerCase().includes('whisky') || item.name.toLowerCase().includes('vodka') || item.name.toLowerCase().includes('gin') || item.name.toLowerCase().includes('alcohol')) {
      const kcalVal = Math.round((item.kcal_per100g || 0) * (item.weight_g / 100));
      if (kcalVal > 0) {
        alcoholNote = `<div class="nia-alert nia-alert-warn" style="margin-top:0.75rem">🍷 <strong>Bebida alcohólica detectada:</strong> ${item.name} (${item.weight_g}ml) aporta calorías vacías que interfieren con la absorción de nutrientes (vitaminas B y zinc) y elevan el cortisol.</div>`;
      }
    }
  });

  let dietViolationNote = '';
  const nonCompliant = [...niaData.detected, ...niaData.condiments, ...niaData.drink].filter(item => !isFoodCompliantWithDiet(item.name, userDiet));
  if (nonCompliant.length > 0) {
    const names = nonCompliant.map(item => `<strong>${item.name}</strong>`).join(', ');
    dietViolationNote = `<div class="nia-alert nia-alert-warn" style="margin-top:0.75rem; background:rgba(239,83,80,0.12); border:1px solid rgba(239,83,80,0.25); color:#ef5350;">⚠️ <strong>Alerta de Dieta (${userDiet.charAt(0).toUpperCase() + userDiet.slice(1)}):</strong> Este plato contiene ingredientes no compatibles: ${names}. Recordá que tu perfil tiene seleccionada la alimentación base como ${userDiet}.</div>`;
  }

  const baseHTML = `
    <!-- SCORE HERO -->
    <div class="nia-final-hero" style="margin-top:1.25rem">
      <div class="nia-final-score-wrap">
        <div class="nia-final-score-ring">
          <svg viewBox="0 0 80 80">
            <circle cx="40" cy="40" r="32" fill="none" stroke="rgba(255,255,255,.12)" stroke-width="8"/>
            <circle cx="40" cy="40" r="32" fill="none" stroke="url(#pfsgNew)" stroke-width="8"
              stroke-linecap="round" stroke-dasharray="201" stroke-dashoffset="${Math.round(201-(scoreInt/100)*201)}"
              transform="rotate(-90 40 40)"/>
            <defs>
              <linearGradient id="pfsgNew" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stop-color="${scoreInt>=75?'#4ade80':scoreInt>=55?'#fb923c':'#f87171'}"/>
                <stop offset="100%" stop-color="${scoreInt>=75?'#22d3ee':scoreInt>=55?'#fbbf24':'#fb923c'}"/>
              </linearGradient>
            </defs>
          </svg>
          <div class="nia-final-score-num">${scoreInt}</div>
        </div>
        <div class="nia-final-score-info">
          <div class="nia-final-traffic">${trafficLight} ${trafficLabel}</div>
          <div class="nia-final-kcal"><strong>${totalKcal}</strong> kcal totales</div>
          <div class="nia-final-pct">= ${mealPct}% de tu meta diaria</div>
        </div>
      </div>
    </div>

    <!-- INGREDIENTES IDENTIFICADOS -->
    <div class="nia-card nia-analyst-card">
      <div class="nia-analyst-header">
        <span class="nia-analyst-icon">🩺</span>
        <div>
          <h4>Alimentos y Componentes Detectados</h4>
          <p class="nia-sub">Análisis unificado por la Inteligencia Artificial</p>
        </div>
      </div>
      <div class="nia-ing-list">
        ${niaData.detected.map(f => `
          <div class="nia-ing-item">
            <span class="nia-ing-emoji">${f.emoji || '🍽️'}</span>
            <div class="nia-ing-info">
              <span class="nia-ing-name">${f.name}</span>
              <span class="nia-ing-weight">~${f.weight_g}g estimados</span>
            </div>
            <span class="nia-conf-badge conf-high">🟢 Detectado</span>
          </div>`).join('')}
        ${niaData.condiments.map(f => `
          <div class="nia-ing-item">
            <span class="nia-ing-emoji">${f.emoji || '🧂'}</span>
            <div class="nia-ing-info">
              <span class="nia-ing-name">${f.name} (Condimento)</span>
              <span class="nia-ing-weight">~${f.weight_g}g estimado</span>
            </div>
            <span class="nia-conf-badge conf-high" style="background:rgba(251,146,60,0.12);color:var(--orange);border:1px solid rgba(251,146,60,0.3)">🧂 Aderezo</span>
          </div>`).join('')}
        ${niaData.drink.map(f => `
          <div class="nia-ing-item">
            <span class="nia-ing-emoji">${f.emoji || '🥤'}</span>
            <div class="nia-ing-info">
              <span class="nia-ing-name">${f.name} (Bebida)</span>
              <span class="nia-ing-weight">${f.weight_g} cm³ (ml)</span>
            </div>
            <span class="nia-conf-badge conf-high" style="background:rgba(34,211,238,0.12);color:var(--cyan);border:1px solid rgba(34,211,238,0.3)">🥤 Bebida</span>
          </div>`).join('')}
      </div>
    </div>

    <!-- DETALLE NUTRICIONAL TABLA -->
    <div class="nia-card">
      <h4>📊 Detalle nutricional por componente</h4>
      <div class="nia-table-wrap">
        <table class="nia-table">
          <thead><tr><th>Componente</th><th>Peso/Vol</th><th>kcal</th><th>Prot</th><th>Carb</th><th>Grasa</th></tr></thead>
          <tbody>
            ${[...niaData.detected, ...niaData.condiments, ...niaData.drink].map(f => {
              const fac = f.weight_g/100;
              return `<tr>
                <td>${f.emoji || '🍽️'} ${f.name}</td>
                <td>${f.weight_g}${f.category === 'drink' ? 'ml' : 'g'}</td>
                <td>${Math.round((f.kcal_per100g || 0)*fac)}</td>
                <td>${((f.prot_per100g || 0)*fac).toFixed(1)}g</td>
                <td>${((f.carb_per100g || 0)*fac).toFixed(1)}g</td>
                <td>${((f.fat_per100g || 0)*fac).toFixed(1)}g</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- MACROS DETALLADOS -->
    <div class="nia-card">
      <h4>🧬 Composición nutricional total</h4>
      <div class="nia-macro-bars">
        <div class="nia-macro-bar-row">
          <div class="nia-macro-bar-label">
            <span class="nia-macro-dot" style="background:var(--green)"></span>
            <span>Proteínas</span>
            <span class="nia-macro-bar-val green">${totalProt}g</span>
          </div>
          <div class="nia-macro-bar-track"><div class="nia-macro-bar-fill" style="width:${macroBarProt}%;background:var(--green)"></div></div>
          <span class="nia-macro-bar-pct">${macroBarProt}%</span>
        </div>
        <div class="nia-macro-bar-row">
          <div class="nia-macro-bar-label">
            <span class="nia-macro-dot" style="background:var(--cyan)"></span>
            <span>Carbohidratos</span>
            <span class="nia-macro-bar-val cyan">${totalCarb}g</span>
          </div>
          <div class="nia-macro-bar-track"><div class="nia-macro-bar-fill" style="width:${macroBarCarb}%;background:var(--cyan)"></div></div>
          <span class="nia-macro-bar-pct">${macroBarCarb}%</span>
        </div>
        <div class="nia-macro-bar-row">
          <div class="nia-macro-bar-label">
            <span class="nia-macro-dot" style="background:var(--purple)"></span>
            <span>Grasas</span>
            <span class="nia-macro-bar-val purple">${totalFat}g</span>
          </div>
          <div class="nia-macro-bar-track"><div class="nia-macro-bar-fill" style="width:${macroBarFat}%;background:var(--purple)"></div></div>
          <span class="nia-macro-bar-pct">${macroBarFat}%</span>
        </div>
      </div>
    </div>

    <!-- DESGLOSE CALÓRICO -->
    <div class="nia-card">
      <h4>📦 Desglose calórico</h4>
      <div class="nia-breakdown-list">
        <div class="nia-breakdown-row"><span>🍽️ Plato principal</span><span><strong>${Math.round(niaData.baseTotals.kcal)} kcal</strong></span></div>
        ${niaData.condiments.length ? `<div class="nia-breakdown-row"><span>🧂 Condimentos</span><span>+${Math.round(niaData.condTotals.kcal)} kcal</span></div>` : ''}
        ${niaData.drink.length ? `<div class="nia-breakdown-row"><span>🥤 Bebida</span><span>+${Math.round(niaData.drinkTotals.kcal)} kcal</span></div>` : ''}
        <div class="nia-breakdown-row nia-breakdown-total"><span>TOTAL</span><span><strong>${totalKcal} kcal</strong></span></div>
      </div>
      <div class="nia-pct-bar-wrap">
        <p style="font-size:.78rem;color:var(--text-muted);margin-bottom:.4rem">Representa el <strong>${mealPct}%</strong> de tu objetivo diario (${targetCals} kcal)</p>
        <div class="nia-pct-bar"><div class="nia-pct-fill" style="width:${Math.min(100,mealPct)}%;background:${mealPct>50?'var(--orange)':'var(--green)'}"></div></div>
      </div>
    </div>

    ${alcoholNote}
    ${dietViolationNote}

    <!-- VALORACIÓN CLÍNICA -->
    <div class="nia-card nia-assessment">
      <h4>🩺 Valoración Nutricional Personalizada</h4>
      <div class="nia-clinical-note">${niaData.clinicalAssessment}</div>
      <div style="font-size: 0.65rem; color: var(--text-dim); margin-top: 10px; padding-top: 6px; border-top: 1px dashed rgba(255,255,255,0.08); font-style: italic; line-height: 1.3;">*Aviso: Esta valoración es de carácter informativo y general basada en IA. No reemplaza ni sustituye las indicaciones personalizadas de tu médico, nutricionista o deportólogo profesional.*</div>
      ${suggestions.length ? `
        <div class="nia-suggestions">
          <p style="font-weight:600;font-size:.82rem;margin-bottom:.4rem;color:var(--text-muted)">Recomendaciones:</p>
          ${suggestions.map(s=>`<div class="nia-sugg-item-card">${s}</div>`).join('')}
        </div>` :
        '<div class="nia-no-sugg">✅ Sin recomendaciones adicionales — ¡excelente elección para tu objetivo!</div>'}
    </div>`;

  document.getElementById('nia-final-report').innerHTML = baseHTML;
}

function niaAddToLog() {
  const plate = niaData.detected || [];
  const drink = niaData.drink || [];
  
  let nameParts = plate.map(f => f.name);
  if (drink.length > 0) {
    nameParts.push(drink.map(d => d.name).join(' · '));
  }
  
  const name = nameParts.length > 0 ? nameParts.join(' + ') : 'Análisis de foto';
  const meal = {
    id: Date.now(),
    name,
    emoji: '📸',
    type: niaData.mealType || 'almuerzo',
    kcal: niaData.finalKcal || 0,
    prot: niaData.finalProt || 0,
    carb: niaData.finalCarb || 0,
    fat: niaData.finalFat || 0,
    score: niaData.score || 70,
    qty: 0,
    date: niaTargetMealDate ? niaTargetMealDate.toDateString() : new Date().toDateString()
  };
  meals.push(meal);
  localStorage.setItem('nutriMeals', JSON.stringify(meals));
  if (typeof niaPostLog === 'function') {
    const dateStr = meal.date ? niaStandardizeDate(meal.date) : new Date().toISOString().split('T')[0];
    niaPostLog('meal', meal, dateStr).then(id => {
      if (id) {
        meal.saasId = id;
        localStorage.setItem('nutriMeals', JSON.stringify(meals));
      }
    });
  }
  niaSendToGoogleSheets(meal);
  
  if (niaSelectedDrink !== 'ninguna' && niaDrinkMl > 0) {
    const drinkDate = niaTargetMealDate 
      ? niaTargetMealDate.toISOString().split('T')[0] 
      : (typeof getTodayStr === 'function' ? getTodayStr() : new Date().toISOString().split('T')[0]);
    const drinkName = niaSelectedDrink === 'otro' ? (niaCustomDrink || 'Otra bebida') : (PA_DRINKS[niaSelectedDrink]?.label || 'Bebida');
    
    if (typeof hydrationLog !== 'undefined') {
      hydrationLog.push({
        ml: niaDrinkMl,
        time: new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' }),
        date: drinkDate,
        timestamp: Date.now(),
        source: drinkName
      });
      if (typeof saveNewFeatureData === 'function') {
        saveNewFeatureData();
      } else {
        localStorage.setItem('nutriHydrationLog', JSON.stringify(hydrationLog));
      }
      if (typeof updateHydrationUI === 'function') {
        updateHydrationUI();
      }
    }
  }
  
  if (typeof renderProgressCharts === 'function') {
    renderProgressCharts(currentPeriodDays);
  }
  if (typeof checkAchievements === 'function') {
    checkAchievements();
  }
  
  updateDailyProgressBar();
  showMsg("¡Excelente elección! Plato registrado con éxito. ¡Seguí así para alcanzar tu meta de hoy! 🥗🔥");
  niaCancelMealsFlow();
}

function niaReset() {
  niaPhotoData = null;
  niaPhotoMime = null;
  niaSelectedMealType = 'almuerzo';
  niaSelectedInvisibleIngredients = [];
  niaCustomInvisibleIngredients = '';
  niaSelectedDrink = 'ninguna';
  niaDrinkMl = 250;
  niaCustomDrink = '';
  niaAlcoholPct = 0;

  const cameraBtn = document.getElementById('nia-btn-camera');
  if (cameraBtn) cameraBtn.style.display = 'flex';

  const contextEl = document.getElementById('photo-context');
  if (contextEl) contextEl.value = '';

  const textDesc = document.getElementById('food-text-description');
  if (textDesc) textDesc.value = '';

  niaRemovePhoto();

  const panel = document.getElementById('photo-analysis-panel');
  if (panel) panel.classList.add('hidden');
  const spinnerBlock = document.getElementById('nia-loading-spinner-block');
  if (spinnerBlock) spinnerBlock.classList.add('hidden');
  const reportBlock = document.getElementById('nia-final-report-block');
  if (reportBlock) reportBlock.classList.add('hidden');
  const editBlock = document.getElementById('nia-edit-ingredients-block');
  if (editBlock) editBlock.classList.add('hidden');

  const finalRep = document.getElementById('nia-final-report');
  if (finalRep) finalRep.innerHTML = '';
}

function renderPaManualEntry(lowQuality, errDetail) {
  const finalRep = document.getElementById('nia-final-report');
  if (!finalRep) return;

  let msg = lowQuality 
    ? '⚠️ No pudimos identificar los ingredientes de la foto. Por favor, intenta de nuevo con una toma más clara y con buena iluminación, o intenta más tarde.' 
    : '❌ Error al conectar con la IA de análisis. Por favor, intenta de nuevo o verifica tu conexión a internet.';

  if (errDetail) {
    msg += `<br><br><span style="font-size:0.75rem;color:#f87171;font-family:monospace;background:rgba(0,0,0,0.05);padding:4px 8px;border-radius:4px;display:inline-block">Detalle del error: ${errDetail}</span>`;
  }

  finalRep.innerHTML = `
    <div class="nia-card" style="text-align:center;padding:2rem 1.5rem;border-color:rgba(200,29,58,0.2)">
      <div style="font-size:2.5rem;margin-bottom:1rem">📝</div>
      <p style="font-weight:700;margin-bottom:0.5rem;font-size:1rem;color:var(--text)">Entrada manual / Fallo de IA</p>
      <p style="font-size:0.85rem;color:var(--text-dim);line-height:1.5;margin-bottom:1.25rem">${msg}</p>
      <button class="btn-primary btn-full" onclick="niaReset()">Intentar de nuevo</button>
    </div>
  `;

  const panel = document.getElementById('photo-analysis-panel');
  if (panel) panel.classList.remove('hidden');
  const spinnerBlock = document.getElementById('nia-loading-spinner-block');
  if (spinnerBlock) spinnerBlock.classList.add('hidden');
  const reportBlock = document.getElementById('nia-final-report-block');
  if (reportBlock) reportBlock.classList.remove('hidden');
  const editBlock = document.getElementById('nia-edit-ingredients-block');
  if (editBlock) editBlock.classList.add('hidden');
}


function addMeal() {
    if (!currentAnalysis) return;
    const m = {
        id: Date.now(), name: currentAnalysis.name || currentAnalysis.rawName, emoji: currentAnalysis.emoji || '🍽️',
        type: currentAnalysis.mealType, kcal: currentAnalysis.kcalTotal, prot: currentAnalysis.protTotal,
        carb: currentAnalysis.carbTotal, fat: currentAnalysis.fatTotal, score: currentAnalysis.score,
        qty: currentAnalysis.qty, date: new Date().toDateString()
    };
    meals.push(m); localStorage.setItem('nutriMeals', JSON.stringify(meals));
    if (typeof niaPostLog === 'function') {
        const dateStr = m.date ? niaStandardizeDate(m.date) : new Date().toISOString().split('T')[0];
        niaPostLog('meal', m, dateStr).then(id => {
            if (id) {
                m.saasId = id;
                localStorage.setItem('nutriMeals', JSON.stringify(meals));
            }
        });
    }
    niaSendToGoogleSheets(m);
    currentAnalysis = null;
    document.getElementById('analysis-result').classList.add('hidden');
    document.getElementById('food-search').value = '';
    updateDailyProgressBar();
    renderMealsLog(); updateDashboard(); updateNutricion(); showMsg("¡Buenísimo! Comida agregada al registro de hoy. ¡Tu progreso diario avanza! 🥗🚀");
}
function deleteMeal(id) {
    const mealToDelete = meals.find(m => m.id === id);
    if (mealToDelete && mealToDelete.saasId && typeof niaDeleteLog === 'function') {
        niaDeleteLog(mealToDelete.saasId);
    }
    meals = meals.filter(m => m.id !== id); localStorage.setItem('nutriMeals', JSON.stringify(meals));
    updateDailyProgressBar();
    renderMealsLog(); updateDashboard(); updateNutricion();
}
function renderMealsLog() {
    const log = document.getElementById('meals-log'); if (!log) return;
    const valContainer = document.getElementById('nia-daily-valuation-container');
    const today = getTodayMeals();
    
    const titleEl = document.getElementById('nia-log-title');
    if (titleEl) {
        if (niaTargetMealDate) {
            const options = { weekday: 'long', day: 'numeric', month: 'long' };
            const formatted = niaTargetMealDate.toLocaleDateString('es-AR', options);
            titleEl.textContent = `Registro del ${formatted.charAt(0).toUpperCase() + formatted.slice(1)}`;
        } else {
            titleEl.textContent = 'Registro de hoy';
        }
    }
    
    if (today.length === 0) {
        if (valContainer) valContainer.innerHTML = '';
        log.innerHTML = `<p class="empty-note">No hay comidas registradas ${niaTargetMealDate ? 'para este día' : 'hoy'}.</p>`;
        return;
    }
    
    // --- PASO 5: VALORACIÓN EN CONJUNTO (CONSOLIDADA) ---
    const tot = calcTotals(today);
    const targetCals = profile.targetCals || 2000;
    const pctCons = Math.round((tot.kcal / targetCals) * 100);

    const protCals = tot.prot * 4;
    const carbCals = tot.carb * 4;
    const fatCals = tot.fat * 9;
    const totalCalcCals = protCals + carbCals + fatCals;

    let protPct = 20, carbPct = 50, fatPct = 30;
    if (totalCalcCals > 0) {
        protPct = Math.round((protCals / totalCalcCals) * 100);
        carbPct = Math.round((carbCals / totalCalcCals) * 100);
        fatPct = Math.round((fatCals / totalCalcCals) * 100);
    }

    let badgeText = 'Equilibrado';
    let badgeBg = 'rgba(76,175,80,0.1)';
    let badgeColor = 'var(--green)';
    let circleBg = 'rgba(76,175,80,0.05)';
    let circleColor = 'var(--green)';
    let circleBorder = 'rgba(76,175,80,0.2)';
    let progressBarColor = 'var(--green)';

    if (pctCons > 105) {
        badgeText = 'Exceso Calórico';
        badgeBg = 'rgba(200,29,58,0.1)';
        badgeColor = '#c81d3a';
        circleBg = 'rgba(200,29,58,0.05)';
        circleColor = '#c81d3a';
        circleBorder = 'rgba(200,29,58,0.2)';
        progressBarColor = '#c81d3a';
    } else if (pctCons > 85) {
        badgeText = 'Meta Alcanzada';
        badgeBg = 'rgba(76,175,80,0.1)';
        badgeColor = 'var(--green)';
        progressBarColor = 'var(--green)';
    } else if (pctCons > 40) {
        badgeText = 'Buen Ritmo';
        badgeBg = 'rgba(255,152,0,0.1)';
        badgeColor = '#ef6c00';
        circleBg = 'rgba(255,152,0,0.05)';
        circleColor = '#ef6c00';
        circleBorder = 'rgba(255,152,0,0.2)';
        progressBarColor = '#ff9800';
    } else {
        badgeText = 'Ingesta Baja';
        badgeBg = 'rgba(0,188,212,0.1)';
        badgeColor = '#00acc1';
        circleBg = 'rgba(0,188,212,0.05)';
        circleColor = '#00acc1';
        circleBorder = 'rgba(0,188,212,0.2)';
        progressBarColor = '#00bcd4';
    }

    let assessmentText = '';
    if (pctCons <= 45) {
        assessmentText += `El consumo total registrado de <strong>${tot.kcal} kcal</strong> cubre el <strong>${pctCons}%</strong> de tu objetivo diario. Es un nivel de ingesta bajo. Te sugerimos asegurar el aporte de energía necesario realizando las comidas principales pendientes para evitar déficits.`;
    } else if (pctCons > 45 && pctCons <= 85) {
        assessmentText += `Llevas registrado un excelente ritmo con <strong>${tot.kcal} kcal</strong> (<strong>${pctCons}%</strong> cubierto). Las comidas registradas están alineadas con tu meta de <strong>${goalLabel(profile.goal)}</strong>. Continúa con esta distribución equilibrada.`;
    } else if (pctCons > 85 && pctCons <= 105) {
        assessmentText += `Has cubierto el <strong>${pctCons}%</strong> de tus calorías diarias esperadas (${tot.kcal} de ${targetCals} kcal). Buen trabajo al ajustar las ingestas diarias dentro de tus límites previstos.`;
    } else {
        assessmentText += `Has alcanzado el <strong>${pctCons}%</strong> de tus calorías diarias, registrando un ingreso de <strong>${tot.kcal} kcal</strong>. Esto representa un excedente energético moderado sobre tu objetivo de ${targetCals} kcal.`;
    }

    assessmentText += '<br><br>';
    
    if (tot.prot < 50) {
        assessmentText += `⚠️ <strong>Proteínas bajas (${Math.round(tot.prot)}g, ${protPct}% kcal):</strong> Recomendamos incorporar más carnes magras, huevo o legumbres para alcanzar un balance proteico adecuado. `;
    } else if (protPct >= 15 && protPct <= 28) {
        assessmentText += `🟢 <strong>Proteínas óptimas (${Math.round(tot.prot)}g, ${protPct}% kcal):</strong> Buena proporción para la reparación de tejidos y saciedad celular. `;
    } else if (protPct > 28) {
        assessmentText += `🟢 <strong>Proteínas altas (${Math.round(tot.prot)}g, ${protPct}% kcal):</strong> Excelente perfil proteico diario para la síntesis muscular. `;
    }

    if (carbPct > 60) {
        assessmentText += `⚠️ <strong>Carbohidratos elevados (${carbPct}% kcal):</strong> Tu ingesta de hoy es rica en almidones o azúcares. Sería prudente elegir carbohidratos complejos altos en fibra. `;
    } else if (carbPct < 30) {
        assessmentText += `🟡 <strong>Carbohidratos bajos (${carbPct}% kcal):</strong> Rango bajo de carbohidratos, útil para definición. Asegura un buen aporte de fibra con hojas verdes. `;
    } else {
        assessmentText += `🟢 <strong>Carbohidratos balanceados (${carbPct}% kcal):</strong> Aporte energético ideal para reponer glucógeno. `;
    }

    if (fatPct > 35) {
        assessmentText += `⚠️ <strong>Grasas elevadas (${fatPct}% kcal):</strong> Tu ingesta de grasas supera la sugerencia del 35%. Modera el uso de aceites al cocinar y prioriza grasas insaturadas de palta, frutos secos o pescado. `;
    } else {
        assessmentText += `🟢 <strong>Grasas balanceadas (${fatPct}% kcal):</strong> Aporte lipídico saludable necesario para la regulación hormonal. `;
    }

    let warningBoxHTML = '';
    if (pctCons > 105) {
        warningBoxHTML = `
        <div class="nia-alert nia-alert-danger" style="margin-top:1rem; display:flex; align-items:flex-start; gap:10px; background:rgba(200,29,58,0.05); border: 1px solid rgba(200,29,58,0.15); padding:10px 12px; border-radius:10px; color:#c81d3a; font-size:0.82rem; line-height:1.4">
          <span style="font-size:1.1rem; line-height:1">🚨</span>
          <div>
            <strong>Llamado de Atención — Exceso Calórico:</strong> Has superado tu objetivo calórico diario en un <strong>${pctCons - 100}%</strong> (+${Math.round(tot.kcal - targetCals)} kcal). Te sugerimos moderar las ingestas de las próximas 24 horas y aumentar la actividad física para compensar el balance energético.
          </div>
        </div>`;
    }

    if (valContainer) {
        valContainer.innerHTML = `
        <div class="nia-card" style="margin-bottom:1.5rem; border:1px solid rgba(200,29,58,0.12); padding:1.25rem; border-radius:16px; background:var(--bg1)">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem">
            <h4 style="margin:0; font-size:0.95rem; font-weight:700; color:var(--text)">📊 Valoración del Día Consolidada</h4>
            <span style="padding:4px 10px; border-radius:100px; font-size:0.7rem; font-weight:700; background:${badgeBg}; color:${badgeColor}">${badgeText}</span>
          </div>
          
          <div style="display:flex; align-items:center; gap:16px; margin-bottom:1rem">
            <div style="position:relative; width:56px; height:56px; flex-shrink:0; border-radius:50%; background:${circleBg}; display:flex; flex-direction:column; align-items:center; justify-content:center; color:${circleColor}; font-weight:800; font-size:0.95rem; border:2.5px solid ${circleBorder}">
              ${pctCons}%
            </div>
            <div style="flex-grow:1">
              <div style="font-size:0.82rem; color:var(--text)">Consumido hoy: <strong style="color:var(--green)">${tot.kcal} kcal</strong> de <strong>${targetCals} kcal</strong></div>
              <div style="font-size:0.76rem; color:var(--text-muted); margin-top:2px">Objetivo diario: ${pctCons}% cubierto</div>
              <div style="height:6px; margin-top:6px; background:rgba(0,0,0,0.05); border-radius:3px; overflow:hidden">
                <div style="height:100%; width:${Math.min(100, pctCons)}%; background:${progressBarColor}; border-radius:3px; transition:width 0.5s ease"></div>
              </div>
            </div>
          </div>

          <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px; margin-bottom:1rem">
            <div style="background:rgba(76,175,80,0.04); padding:6px; border-radius:8px; text-align:center; border:1px solid rgba(76,175,80,0.08)">
              <div style="font-size:0.65rem; color:var(--text-muted); text-transform:uppercase; font-weight:700">Proteínas</div>
              <div style="font-size:0.8rem; font-weight:700; color:var(--green); margin-top:2px">${Math.round(tot.prot)}g</div>
            </div>
            <div style="background:rgba(0,188,212,0.04); padding:6px; border-radius:8px; text-align:center; border:1px solid rgba(0,188,212,0.08)">
              <div style="font-size:0.65rem; color:var(--text-muted); text-transform:uppercase; font-weight:700">Carbohidratos</div>
              <div style="font-size:0.8rem; font-weight:700; color:var(--cyan); margin-top:2px">${Math.round(tot.carb)}g</div>
            </div>
            <div style="background:rgba(156,39,176,0.04); padding:6px; border-radius:8px; text-align:center; border:1px solid rgba(156,39,176,0.08)">
              <div style="font-size:0.65rem; color:var(--text-muted); text-transform:uppercase; font-weight:700">Grasas</div>
              <div style="font-size:0.8rem; font-weight:700; color:var(--purple); margin-top:2px">${Math.round(tot.fat)}g</div>
            </div>
          </div>

          <div style="font-size:0.82rem; line-height:1.45; color:var(--text); background:rgba(0,0,0,0.02); padding:10px 12px; border-radius:10px; border-left:3px solid ${progressBarColor}">
            ${assessmentText}
          </div>

          ${warningBoxHTML}
        </div>
        `;
    }

    const groups = ['desayuno', 'almuerzo', 'merienda', 'cena', 'snack'];
    const labels = { desayuno: '🌅 Desayuno', almuerzo: '☀️ Almuerzo', merienda: '🍎 Merienda', cena: '🌙 Cena', snack: '🥜 Snack' };
    let html = '';
    groups.forEach(g => {
        const gm = today.filter(m => m.type === g); if (!gm.length) return;
        html += `<p style="font-size:.76rem;color:var(--text-muted);margin:.75rem 0 .4rem">${labels[g]}</p>`;
        gm.forEach(m => { html += mealItemHTML(m); });
    });
    log.innerHTML = html;
}
function mealItemHTML(m) {
    const bc = m.score >= 75 ? 'badge-green' : m.score >= 55 ? 'badge-orange' : 'badge-red';
    return `<div class="meal-item"><span class="meal-icon">${m.emoji}</span>
    <div class="meal-detail"><div class="meal-name">${m.name}</div>
    <div class="meal-meta">${m.qty}g · ${m.kcal} kcal · P:${m.prot}g C:${m.carb}g G:${m.fat}g</div></div>
    <div class="meal-score-badge ${bc}">${m.score}</div>
    <div style="display:flex; gap:6px; align-items:center; flex-shrink:0;">
      <button class="meal-edit" onclick="niaOpenEditMealModal(${m.id})">✏️</button>
      <button class="meal-delete" onclick="deleteMeal(${m.id})">🗑</button>
    </div></div>`;
}

// ===== NUTRICIÓN PAGE =====
function updateNutricion() {
    const today = getTodayMeals(), tot = calcTotals(today);
    const score = calcDailyScore(tot, today);
    updateScoreRing(score);
    const pg = profile.prot || 120, cg = profile.carb || 180, fg = profile.fat || 60;
    document.getElementById('macros-detail').innerHTML =
        [{ n: 'Proteínas', c: 'green', v: Math.round(tot.prot), g: pg, cls: 'prot-bar' },
        { n: 'Carbohidratos', c: 'cyan', v: Math.round(tot.carb), g: cg, cls: 'carb-bar' },
        { n: 'Grasas', c: 'purple', v: Math.round(tot.fat), g: fg, cls: 'fat-bar' }].map(({ n, c, v, g, cls }) =>
            `<div class="macro-detail-item glass-card">
      <div class="macro-d-header"><span class="macro-d-name" style="color:var(--${c})">${n}</span><span class="macro-d-nums">${v}g / ${g}g</span></div>
      <div class="macro-d-bar-wrap"><div class="macro-d-bar ${cls}" style="width:${Math.min(100, (v / g) * 100)}%"></div></div>
    </div>`).join('');
    document.getElementById('micros-grid').innerHTML = MICROS_MAP.map(m => {
        const v = Math.round(m.good * (0.2 + Math.random() * 0.9)), p = Math.round(v / m.good * 100);
        return `<div class="micro-card"><div class="micro-card-name">${m.icon} ${m.name}</div>
      <div class="micro-card-val">${v}${m.unit}</div>
      <div class="micro-card-pct ${p >= 60 ? 'pct-good' : 'pct-low'}">${p}% del objetivo</div></div>`;
    }).join('');
    const avg = today.length > 0 ? today.reduce((s, m) => s + m.score, 0) / today.length : 72;
    
    // Get yesterday's average score for trend calculation (UX-P1-10)
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yKey = yesterday.toDateString();
    const yesterdayMeals = meals.filter(m => m.date === yKey);
    const yesterdayAvg = yesterdayMeals.length > 0 ? yesterdayMeals.reduce((s, m) => s + m.score, 0) / yesterdayMeals.length : 72;

    const idsMap = {
        'imp-cardio': 'val-cardio',
        'imp-meta': 'val-meta',
        'imp-micro': 'val-micro'
    };
    
    ['imp-cardio', 'imp-meta', 'imp-micro'].forEach((id, i) => {
        const currentScore = Math.round(avg + (i - 1) * 5);
        const yesterdayScore = Math.round(yesterdayAvg + (i - 1) * 5);
        
        let trend = '→';
        let trendColor = 'var(--text-dim)';
        if (currentScore > yesterdayScore) {
            trend = '↑';
            trendColor = 'var(--green)';
        } else if (currentScore < yesterdayScore) {
            trend = '↓';
            trendColor = 'var(--red)';
        }
        
        const bar = document.getElementById(id);
        if (bar) bar.style.width = currentScore + '%';
        
        const txt = document.getElementById(idsMap[id]);
        if (txt) {
            txt.innerHTML = `<span style="color:${trendColor}; margin-right:4px; font-weight:bold;">${trend}</span> ${currentScore} / 100`;
        }
    });
}

// ===== UTILS =====
function getTodayMeals() {
    const d = window.niaHomeSelectedDate || new Date();
    const t = d.toDateString();
    return meals.filter(m => m.date === t);
}
function getTodayActivities() {
    const d = window.niaActivitySelectedDate || new Date();
    const t = d.toDateString();
    return activities.filter(a => a.date === t);
}
function calcTotals(list) { return list.reduce((a, m) => ({ kcal: a.kcal + (m.kcal || 0), prot: a.prot + (m.prot || 0), carb: a.carb + (m.carb || 0), fat: a.fat + (m.fat || 0) }), { kcal: 0, prot: 0, carb: 0, fat: 0 }); }
function goalLabel(g) {
    if (!g) return 'salud general';
    const goalsArray = Array.isArray(g) ? g : (typeof g === 'string' ? g.split(',') : [g]);
    const labels = {
        perderPeso: 'disminuir masa grasa',
        ganarMusculo: 'ganar músculo',
        recomposicion: 'recomposición corporal',
        saludGeneral: 'salud general',
        longevidad: 'longevidad',
        energia: 'aumentar energía',
        rendimientoDeportivo: 'rendimiento deportivo',
        saludMental: 'salud mental',
        recuperacionMedica: 'recuperación de problema médico'
    };
    return goalsArray.map(x => labels[x.trim()] || x).join(', ');
}
function showMsg(msg) {
    const t = document.createElement('div');
    t.className = 'badge-notification';
    t.innerHTML = `<div>${msg}</div>`;
    document.body.appendChild(t);
    setTimeout(() => t.classList.add('show'), 10);
    setTimeout(() => {
        t.classList.remove('show');
        setTimeout(() => t.remove(), 400);
    }, 2500);
}
function resetApp() { if (confirm('¿Reiniciar tu perfil? Se borrarán todos tus datos.')) { localStorage.clear(); location.reload(); } }

// ===== FOOD AUTOCOMPLETE =====
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.search.includes('reset=true')) {
        localStorage.removeItem('nutriProfile');
        localStorage.removeItem('nutriMeals');
        localStorage.removeItem('nutriSupps');
        localStorage.removeItem('nutriActivities');
        localStorage.removeItem('nutriMetrics');
        window.location.href = window.location.origin + window.location.pathname;
        return;
    }
    const fs = document.getElementById('food-search');
    if (fs) fs.addEventListener('input', () => {
        const val = fs.value.trim().toLowerCase(), sugg = document.getElementById('food-suggestions');
        if (val.length < 2) { sugg.innerHTML = ''; return; }
        const m = FOOD_DB.filter(f => f.name.toLowerCase().includes(val) && isFoodCompliantWithDiet(f.name, profile.diet)).slice(0, 5);
        sugg.innerHTML = m.length ? m.map(f => `<div class="food-sugg-item" onclick="selectFoodSugg('${f.name}')">${f.emoji} ${f.name} — ${f.kcal} kcal/100g</div>`).join('') : '';
    });
    // Activity calorie estimate on change
    ['act-type', 'act-duration', 'act-intensity'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', updateKcalEstimate);
    });
    const dur = document.getElementById('act-duration');
    if (dur) dur.addEventListener('input', updateKcalEstimate);
    loadApp();
});
function selectFoodSugg(name) {
    document.getElementById('food-search').value = name;
    document.getElementById('food-suggestions').innerHTML = '';
    analyzeFood();
}

// ===== LOAD =====
function loadApp() {
    // Migrar claves heredadas de localStorage si existen
    if (localStorage.getItem('paGeminiKey') && !localStorage.getItem('niaGeminiKey')) {
        localStorage.setItem('niaGeminiKey', localStorage.getItem('paGeminiKey'));
    }
    if (localStorage.getItem('paSheetsUrl') && !localStorage.getItem('niaSheetsUrl')) {
        localStorage.setItem('niaSheetsUrl', localStorage.getItem('paSheetsUrl'));
    }

    if (typeof niaAttachOnboardingValidators === 'function') {
        niaAttachOnboardingValidators();
    }

    const sp = localStorage.getItem('nutriProfile');
    if (sp) {
        profile = JSON.parse(sp);
        const sm = localStorage.getItem('nutriMeals'); if (sm) meals = JSON.parse(sm);
        const ss = localStorage.getItem('nutriSupps'); if (ss) supplements = JSON.parse(ss);
        
        // Auto-reset daily taken status for supplements (UX-P1-14)
        const todayStr = new Date().toDateString();
        const lastReset = localStorage.getItem('niaLastSuppResetDate');
        if (lastReset !== todayStr) {
            supplements.forEach(s => s.taken = false);
            localStorage.setItem('nutriSupps', JSON.stringify(supplements));
            localStorage.setItem('niaLastSuppResetDate', todayStr);
        }
        const sa = localStorage.getItem('nutriActivities'); if (sa) activities = JSON.parse(sa);
        const savedMetrics = localStorage.getItem('nutriMetrics'); if (savedMetrics) metrics = JSON.parse(savedMetrics);
        
        // Populate inputs if profile exists so they can review their current settings
        niaPopulateOnboardingInputs();

        // Bypass onboarding and show the main application dashboard
        document.getElementById('onboarding').classList.remove('active');
        document.getElementById('app').classList.add('active');
        updateDashboard();
        updateNutricion();
        updateProfile();
        if (typeof niaUpdateSaaSUI === 'function') {
            niaUpdateSaaSUI();
        }
        showScreen('inicio');
        renderMealsLog();
    } else {
        // If no profile exists, prompt user with onboarding screen step 1
        document.getElementById('onboarding').classList.add('active');
        document.getElementById('app').classList.remove('active');
        nextOnbStep(1);
    }
    
    const savedUrl = localStorage.getItem('niaSheetsUrl');
    const sheetsInput = document.getElementById('nia-sheets-url');
    if (sheetsInput && savedUrl) sheetsInput.value = savedUrl;
}

function displayProgresoMotivationalMessage() {
    const rawName = profile.name ? profile.name.trim() : '';
    const firstName = rawName.split(' ')[0] || '';
    const nameCap = firstName ? (firstName.charAt(0).toUpperCase() + firstName.slice(1)) : '';
    
    let motivation = '';
    const goal = profile.goal || '';
    if (goal.includes('perderPeso')) {
        motivation = `¡Qué bueno verte de nuevo${nameCap ? ', ' + nameCap : ''}! Estás en el camino correcto para disminuir tu masa grasa y mejorar tu salud. ¡La constancia es la clave! 📉✨`;
    } else if (goal.includes('ganarMusculo')) {
        motivation = `¡Qué bueno verte de nuevo${nameCap ? ', ' + nameCap : ''}! Cada día cuenta para nutrir tus fibras y ganar masa muscular. ¡A seguir entrenando fuerte! 💪🔥`;
    } else if (goal.includes('recuperacionMedica')) {
        motivation = `¡Qué bueno verte de nuevo${nameCap ? ', ' + nameCap : ''}! Estabilizar tu digestión es un camino de constancia y bienestar. ¡Tu cuerpo te lo agradece hoy! 🩺🌱`;
    } else {
        motivation = `¡Qué bueno verte de nuevo${nameCap ? ', ' + nameCap : ''}! Cada paso y registro te acerca un poco más a tus metas de bienestar. ¡Sigamos construyendo hábitos saludables hoy! 🌟🧬`;
    }
    
    const bannerEl = document.getElementById('progreso-motivational-banner');
    const textEl = document.getElementById('progreso-motivational-text');
    if (bannerEl && textEl) {
        textEl.innerHTML = motivation;
        bannerEl.classList.remove('hidden');
    }
}

// ===== GOOGLE SHEETS & PDF EXPORT SYSTEM =====

const APPS_SCRIPT_TEMPLATE = `function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "Fecha", 
        "Momento", 
        "Detalle Comida", 
        "Calorias (kcal)", 
        "Proteinas (g)", 
        "Carbohidratos (g)", 
        "Grasas (g)", 
        "Puntaje Nutricional"
      ]);
    }
    
    sheet.appendRow([
      data.date,
      data.type,
      data.name,
      data.kcal,
      data.prot,
      data.carb,
      data.fat,
      data.score
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({ status: "success" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", message: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`;

function niaCopyAppsScriptCode() {
  navigator.clipboard.writeText(APPS_SCRIPT_TEMPLATE)
    .then(() => showMsg('✅ Código copiado al portapapeles. Pégalo en tu Google Apps Script.'))
    .catch(() => showMsg('Error al copiar el código. Inténtalo seleccionando el texto manualmente.'));
}

function niaToggleSheetsHelp() {
  const panel = document.getElementById('nia-sheets-help-panel');
  if (panel) {
    panel.classList.toggle('hidden');
  }
}

function niaSaveSheetsConfig() {
  if (localStorage.getItem('niaSaaSPremium') !== 'true') {
    openPremiumModal('report', document.getElementById('nia-report-card'));
    return;
  }
  const input = document.getElementById('nia-sheets-url');
  if (!input) return;
  const url = input.value.trim();
  
  if (url === '') {
    localStorage.removeItem('niaSheetsUrl');
    showMsg('Desconectado de Google Sheets.');
    return;
  }
  
  if (!url.startsWith('https://script.google.com/')) {
    showMsg('❌ URL inválida. Debe comenzar con https://script.google.com/');
    return;
  }
  
  localStorage.setItem('niaSheetsUrl', url);
  showMsg('✅ Planilla de Google Sheets conectada.');
}

function niaSendToGoogleSheets(entry) {
  const url = localStorage.getItem('niaSheetsUrl');
  if (!url) return;

  let payload;
  const dateObj = new Date(entry.date);
  const formattedDate = isNaN(dateObj.getTime()) ? entry.date : dateObj.toLocaleDateString();

  if (entry.duration !== undefined) {
    // Es una actividad física
    const actName = (typeof ACTIVITY_NAMES !== 'undefined' && ACTIVITY_NAMES[entry.type]) || entry.type;
    payload = {
      date: formattedDate,
      type: 'Actividad',
      name: `${actName} (${entry.duration} min, ${entry.intensity || 'moderada'})`,
      kcal: -entry.kcal, // Calorías quemadas (negativas para el balance neto)
      prot: 0,
      carb: 0,
      fat: 0,
      score: 0
    };
  } else {
    // Es una comida
    payload = {
      date: formattedDate,
      type: entry.type,
      name: entry.name,
      kcal: entry.kcal,
      prot: entry.prot,
      carb: entry.carb,
      fat: entry.fat,
      score: entry.score
    };
  }

  fetch(url, {
    method: 'POST',
    mode: 'no-cors',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(() => {
    console.log('Sync: Registro sincronizado con Google Sheets.');
  })
  .catch(err => {
    console.error('Sync Error: Fallo al sincronizar con Google Sheets:', err);
  });
}

function niaDownloadPDFReport() {
  if (localStorage.getItem('niaSaaSPremium') !== 'true') {
    openPremiumModal('report', document.getElementById('nia-report-card'));
    return;
  }
  const rangeSelect = document.getElementById('nia-pdf-range');
  const range = rangeSelect ? rangeSelect.value : 'today';
  
  const todayStr = new Date().toDateString();
  let filteredMeals = [];
  let filteredActs = [];
  let titleRange = '';

  if (range === 'today') {
    filteredMeals = meals.filter(m => m.date === todayStr);
    filteredActs = activities.filter(a => a.date === todayStr);
    titleRange = 'Hoy';
  } else if (range === 'week') {
    const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
    filteredMeals = meals.filter(m => {
      const mDate = new Date(m.date).getTime();
      return mDate >= cutoff;
    });
    filteredActs = activities.filter(a => {
      const aDate = new Date(a.date).getTime();
      return aDate >= cutoff;
    });
    titleRange = 'Semanal (Últimos 7 días)';
  } else if (range === 'month') {
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
    filteredMeals = meals.filter(m => {
      const mDate = new Date(m.date).getTime();
      return mDate >= cutoff;
    });
    filteredActs = activities.filter(a => {
      const aDate = new Date(a.date).getTime();
      return aDate >= cutoff;
    });
    titleRange = 'Mensual (Últimos 30 días)';
  }

  if (filteredMeals.length === 0 && filteredActs.length === 0) {
    showMsg('⚠️ No hay comidas ni actividades registradas en este rango.');
    return;
  }

  filteredMeals.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  filteredActs.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    const primaryColor = [200, 29, 58];
    const secondaryColor = [30, 41, 59];

    // Header bar
    doc.setFillColor(...primaryColor);
    doc.rect(0, 0, 210, 15, 'F');
    
    // Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(14);
    doc.setTextColor(255, 255, 255);
    doc.text("NUTRICIÓN IA — REPORTE DE NUTRICIÓN CLÍNICA", 14, 10);
    
    // Sub-info
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...secondaryColor);
    doc.text(`Rango del Reporte: ${titleRange}`, 14, 25);
    doc.text(`Fecha de Emisión: ${new Date().toLocaleDateString()}`, 14, 30);
    
    // Profile
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Información del Paciente:", 14, 40);
    
    doc.setFont("helvetica", "normal");
    const name = profile.name || 'Usuario';
    const age = profile.age || '--';
    const weight = profile.weight || '--';
    const height = profile.height || '--';
    const goal = goalLabel(profile.goal) || 'Salud General';
    const targetCals = profile.targetCals || 2000;

    const dietLabel = {
      omnivoro: 'Omnívoro',
      vegetariano: 'Vegetariano',
      vegano: 'Vegano',
      keto: 'Cetogénica (Keto)',
      paleo: 'Paleolítica',
      ayuno: 'Ayuno Intermitente'
    }[profile.diet] || profile.diet || 'Omnívoro';

    doc.text(`Nombre: ${name} (Edad: ${age} años)`, 14, 46);
    doc.text(`Peso: ${weight} kg  |  Altura: ${height} cm`, 14, 51);
    doc.text(`Alimentación: ${dietLabel}  |  Objetivo: ${goal}`, 14, 56);
    doc.text(`Objetivo Calórico Diario: ${targetCals} kcal`, 14, 61);
    
    // Summary
    const totalKcal = filteredMeals.reduce((s, m) => s + m.kcal, 0);
    const avgScore = filteredMeals.length > 0 ? Math.round(filteredMeals.reduce((s, m) => s + m.score, 0) / filteredMeals.length) : 0;
    const totalProt = filteredMeals.reduce((s, m) => s + m.prot, 0);
    const totalCarb = filteredMeals.reduce((s, m) => s + m.carb, 0);
    const totalFat = filteredMeals.reduce((s, m) => s + m.fat, 0);

    const burnedKcal = filteredActs.reduce((s, a) => s + (a.kcal || 0), 0);
    const netKcal = totalKcal - burnedKcal;

    doc.setFont("helvetica", "bold");
    doc.text("Resumen Consolidado del Período:", 110, 40);
    doc.setFont("helvetica", "normal");
    doc.text(`Ingesta: ${totalKcal} kcal (${filteredMeals.length} comidas)`, 110, 46);
    doc.text(`Gasto Actividad: ${burnedKcal} kcal (${filteredActs.length} reg.)`, 110, 51);
    doc.text(`Balance Neto: ${netKcal} kcal`, 110, 56);
    doc.text(`Calidad Promedio: ${filteredMeals.length > 0 ? avgScore + '/100' : 'N/A'}`, 110, 61);

    doc.setDrawColor(220, 220, 220);
    doc.line(14, 68, 196, 68);

    let currentY = 75;

    // Records table
    if (filteredMeals.length > 0) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(...primaryColor);
      doc.text("Detalle de las Ingestas Registradas", 14, currentY);

      const tableData = filteredMeals.map(m => {
        const formattedDate = new Date(m.date).toLocaleDateString();
        const typeLabel = {
          desayuno: 'Desayuno',
          brunch: 'Brunch',
          almuerzo: 'Almuerzo',
          merienda: 'Merienda',
          cena: 'Cena',
          snack: 'Colación'
        }[m.type] || m.type;
        
        return [
          formattedDate,
          typeLabel,
          m.name,
          `${m.kcal} kcal`,
          `P: ${Math.round(m.prot)}g | C: ${Math.round(m.carb)}g | G: ${Math.round(m.fat)}g`,
          `${m.score}/100`
        ];
      });

      doc.autoTable({
        startY: currentY + 5,
        head: [['Fecha', 'Momento', 'Plato / Ingredientes', 'Calorías', 'Macronutrientes', 'Puntaje']],
        body: tableData,
        theme: 'striped',
        headStyles: { fillColor: primaryColor, textColor: [255, 255, 255] },
        columnStyles: {
          0: { cellWidth: 22 },
          1: { cellWidth: 20 },
          2: { cellWidth: 72 },
          3: { cellWidth: 22 },
          4: { cellWidth: 35 },
          5: { cellWidth: 15, halign: 'center' }
        },
        margin: { left: 14, right: 14 },
        styles: { fontSize: 8.5, font: 'helvetica' }
      });

      currentY = doc.lastAutoTable.finalY + 12;
    }

    // Activity table
    if (filteredActs.length > 0) {
      if (currentY > 250) {
        doc.addPage();
        currentY = 25;
      }

      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(...primaryColor);
      doc.text("Detalle de la Actividad Física Registrada", 14, currentY);

      const activityTableData = filteredActs.map(a => {
        const formattedDate = new Date(a.date).toLocaleDateString();
        const actName = (typeof ACTIVITY_NAMES !== 'undefined' && ACTIVITY_NAMES[a.type]) || a.type;
        const duration = `${a.duration || a.dur || 0} min`;
        const intensityLabel = {
          baja: 'Baja',
          moderada: 'Moderada',
          alta: 'Alta',
          maxima: 'Máxima'
        }[a.intensity] || a.intensity;
        const feelingLabel = {
          excelente: 'Excelente',
          bien: 'Bien',
          regular: 'Regular',
          agotado: 'Agotado'
        }[a.feeling] || a.feeling || '--';

        return [
          formattedDate,
          actName,
          duration,
          intensityLabel,
          feelingLabel,
          `${a.kcal} kcal`
        ];
      });

      doc.autoTable({
        startY: currentY + 5,
        head: [['Fecha', 'Actividad', 'Duración', 'Intensidad', 'Sensación', 'Calorías Quemadas']],
        body: activityTableData,
        theme: 'striped',
        headStyles: { fillColor: secondaryColor, textColor: [255, 255, 255] },
        columnStyles: {
          0: { cellWidth: 25 },
          1: { cellWidth: 50 },
          2: { cellWidth: 25 },
          3: { cellWidth: 25 },
          4: { cellWidth: 25 },
          5: { cellWidth: 36, halign: 'right' }
        },
        margin: { left: 14, right: 14 },
        styles: { fontSize: 8.5, font: 'helvetica' }
      });

      currentY = doc.lastAutoTable.finalY + 12;
    }

    // Evaluation
    let finalY = currentY;
    if (finalY > 250) {
      doc.addPage();
      finalY = 25;
    }

    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(...secondaryColor);
    doc.text("Valoración Clínica Sugerida", 14, finalY);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    
    const totalMacros = totalProt + totalCarb + totalFat;
    const pPct = totalMacros > 0 ? Math.round((totalProt / totalMacros) * 100) : 20;
    const cPct = totalMacros > 0 ? Math.round((totalCarb / totalMacros) * 100) : 50;
    const fPct = totalMacros > 0 ? Math.round((totalFat / totalMacros) * 100) : 30;

    let diagnosis = '';
    if (filteredMeals.length > 0) {
      diagnosis = `Durante el período analizado, el paciente registró un puntaje nutricional promedio de ${avgScore}/100. `;
      diagnosis += `La distribución de macronutrientes promedio del período se compone de: Proteínas: ${pPct}%, Carbohidratos: ${cPct}%, Grasas: ${fPct}%. `;
      
      if (avgScore >= 75) {
        diagnosis += "Se observa una excelente adherencia nutricional, con elecciones de platos densos en nutrientes y un balance adecuado de macronutrientes acorde al objetivo del paciente. ";
      } else if (avgScore >= 55) {
        diagnosis += "La calidad nutricional general es aceptable, aunque se identifican márgenes de mejora. Se sugiere revisar la proporción de ultraprocesados, controlar el uso de aderezos e incentivar el consumo de agua. ";
      } else {
        diagnosis += "Se recomienda una revisión nutricional prioritaria. Los registros muestran comidas con desbalances significativos en macronutrientes, baja densidad nutricional o aporte calórico excesivo. ";
      }
    } else {
      diagnosis = "No se registraron ingestas de comida durante este período en el reporte. ";
    }

    if (filteredActs.length > 0) {
      const totalMin = filteredActs.reduce((s, a) => s + (a.duration || a.dur || 0), 0);
      diagnosis += `En relación a la actividad física, se completaron ${filteredActs.length} sesiones de entrenamiento con un gasto energético total estimado de ${burnedKcal} kcal y una duración acumulada de ${totalMin} minutos. `;
      
      if (totalMin >= 150) {
        diagnosis += "El paciente cumple con la recomendación general de la OMS de realizar al menos 150 minutos de actividad física de intensidad moderada por semana, promoviendo la salud cardiovascular y metabólica.";
      } else if (totalMin >= 75) {
        diagnosis += "Se registra un nivel de actividad física regular. Se sugiere intentar incrementar gradualmente la frecuencia o duración de las sesiones para alcanzar la meta óptima de 150 minutos semanales.";
      } else {
        diagnosis += "El nivel de actividad física registrado es bajo. Se aconseja reducir el sedentarismo incorporando caminatas diarias o breves sesiones de movimiento activo adaptadas a su estado físico.";
      }
    } else {
      diagnosis += "No se registraron sesiones de actividad física en este período, lo cual sugiere un patrón sedentario. Se recomienda incorporar paulatinamente rutinas de ejercicio adaptadas.";
    }

    const splitText = doc.splitTextToSize(diagnosis, 180);
    doc.text(splitText, 14, finalY + 6);

    // Footer
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(7.5);
      doc.setTextColor(150, 150, 150);
      doc.text(`Página ${i} de ${pageCount}`, 105, 290, { align: "center" });
      doc.text("Nutrición IA — Desarrollado con inteligencia artificial y base científica.", 14, 290);
    }

    doc.save(`Nutricion_IA_Reporte_Nutricional_${range}.pdf`);
    showMsg('📄 Reporte PDF descargado con éxito.');
  } catch (error) {
    console.error('PDF Generation Error:', error);
    showMsg('❌ Error al generar el archivo PDF: ' + error.message);
  }
}

function niaOpenAddExtraFlow() {
  const container = document.getElementById('nia-extra-flow-container');
  if (container) container.classList.remove('hidden');

  const questionBlock = document.getElementById('nia-extra-question-block');
  const photoBlock = document.getElementById('nia-extra-photo-block');
  const textBlock = document.getElementById('nia-extra-text-block');
  const loading = document.getElementById('nia-extra-loading-block');

  if (questionBlock) questionBlock.classList.remove('hidden');
  if (photoBlock) photoBlock.classList.add('hidden');
  if (textBlock) textBlock.classList.add('hidden');
  if (loading) loading.classList.add('hidden');

  const textarea = document.getElementById('nia-extra-text-description');
  if (textarea) textarea.value = '';

  const input = document.getElementById('extra-photo-input');
  if (input) input.value = '';
}

function niaExtraSelectHasPhoto(hasPhoto) {
  const questionBlock = document.getElementById('nia-extra-question-block');
  const photoBlock = document.getElementById('nia-extra-photo-block');
  const textBlock = document.getElementById('nia-extra-text-block');

  if (questionBlock) questionBlock.classList.add('hidden');
  
  if (hasPhoto) {
    if (photoBlock) photoBlock.classList.remove('hidden');
  } else {
    if (textBlock) textBlock.classList.remove('hidden');
  }
}

function niaCancelExtraFlow() {
  const container = document.getElementById('nia-extra-flow-container');
  if (container) container.classList.add('hidden');
}

function niaDropExtra(e) {
  e.preventDefault();
  const zone = document.getElementById('extra-photo-upload');
  if (zone) zone.classList.remove('dragover');
  if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
    niaProcessExtraFile(e.dataTransfer.files[0]);
  }
}

function niaHandleExtraFileSelect(input) {
  if (input && input.files && input.files[0]) {
    niaProcessExtraFile(input.files[0]);
  }
}

function niaProcessExtraFile(file) {
  if (!file.type.startsWith('image/')) {
    showMsg('Por favor, selecciona un archivo de imagen válido (JPG, PNG, WEBP).');
    return;
  }
  const reader = new FileReader();
  reader.onload = (e) => {
    const dataUrl = e.target.result;
    
    // Add to uploaded photos list and update preview side-by-side
    niaUploadedPhotos.push({ dataUrl, mimeType: file.type || 'image/jpeg' });
    niaRenderPhotosPreview();

    const base64Data = dataUrl.split(',')[1];
    const mimeType = file.type || 'image/jpeg';
    niaAnalyzeExtraPhoto(base64Data, mimeType);
  };
  reader.readAsDataURL(file);
}

async function niaAnalyzeExtraPhoto(base64Data, mimeType) {
  const loading = document.getElementById('nia-extra-loading-block');
  const photoBlock = document.getElementById('nia-extra-photo-block');
  if (loading) loading.classList.remove('hidden');
  if (photoBlock) photoBlock.classList.add('hidden');

  const prompt = `Sos un nutricionista clínico experto. El usuario ha tomado una fotografía de un postre, café, té o elemento agregado a su comida principal.
Identificá los alimentos y componentes visibles en esta fotografía agregada.
Estimá el peso en gramos (weight_g) de cada ingrediente según proporciones típicas.

Respondé ÚNICAMENTE con un objeto JSON válido con el siguiente formato, sin bloques de código markdown, sin texto adicional:
{
  "quality": "good",
  "ingredients": [
    {
      "name": "nombre del ingrediente en español",
      "weight_g": 100,
      "emoji": "🧁"
    }
  ]
}`;

  try {
    const apiKey = localStorage.getItem('niaGeminiKey') || NIA_GEMINI_DEFAULT_KEY;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
    
    const body = {
      contents: [{
        parts: [
          { text: prompt },
          { inline_data: { mime_type: mimeType, data: base64Data } }
        ]
      }],
      generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
    };

    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!resp.ok) throw new Error(`API error ${resp.status}`);

    const data = await resp.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Respuesta no contiene JSON');
    const result = niaParseSafeJSON(jsonMatch[0]);

    if (result.ingredients && result.ingredients.length > 0) {
      const container = document.getElementById('nia-edit-list-container');
      if (container) {
        result.ingredients.forEach(item => {
          container.appendChild(niaCreateEditIngredientRowHTML(item.name, item.weight_g, item.emoji || '🍽️'));
        });
      }
      showMsg(`✅ Agregado(s) incorporado(s) exitosamente.`);
    } else {
      showMsg('⚠️ No se pudieron identificar ingredientes del agregado.');
    }
    // Volver a preguntar si hay otro ingrediente o foto
    niaOpenAddExtraFlow();
  } catch (err) {
    console.error('Error al analizar agregado:', err);
    showMsg('Fallo al analizar el agregado: ' + err.message);
    if (loading) loading.classList.add('hidden');
    if (photoBlock) photoBlock.classList.remove('hidden');
  }
}

async function niaAnalyzeExtraText() {
  const textDesc = document.getElementById('nia-extra-text-description');
  const textValue = textDesc ? textDesc.value.trim() : '';
  if (!textValue) {
    showMsg('Por favor escribe una descripción del agregado.');
    return;
  }

  const loading = document.getElementById('nia-extra-loading-block');
  const textBlock = document.getElementById('nia-extra-text-block');
  if (loading) loading.classList.remove('hidden');
  if (textBlock) textBlock.classList.add('hidden');

  const prompt = `Sos un nutricionista clínico experto. El usuario ha descrito un postre, café, té o elemento agregado a su comida principal:
"${textValue}"

Identificá los ingredientes y componentes del elemento agregado.
Estimá el peso en gramos (weight_g) de cada ingrediente según proporciones típicas o los gramos sugeridos.

Respondé ÚNICAMENTE con un objeto JSON válido con el siguiente formato, sin bloques de código markdown, sin texto adicional:
{
  "quality": "good",
  "ingredients": [
    {
      "name": "nombre del ingrediente en español",
      "weight_g": 100,
      "emoji": "🧁"
    }
  ]
}`;

  try {
    const apiKey = localStorage.getItem('niaGeminiKey') || NIA_GEMINI_DEFAULT_KEY;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
    
    const body = {
      contents: [{
        parts: [{ text: prompt }]
      }],
      generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
    };

    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!resp.ok) throw new Error(`API error ${resp.status}`);

    const data = await resp.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('Respuesta no contiene JSON');
    const result = niaParseSafeJSON(jsonMatch[0]);

    if (result.ingredients && result.ingredients.length > 0) {
      const container = document.getElementById('nia-edit-list-container');
      if (container) {
        result.ingredients.forEach(item => {
          container.appendChild(niaCreateEditIngredientRowHTML(item.name, item.weight_g, item.emoji || '🍽️'));
        });
      }
      showMsg(`✅ Agregado(s) incorporado(s) exitosamente.`);
    } else {
      showMsg('⚠️ No se pudieron identificar ingredientes del agregado.');
    }
    // Volver a preguntar si hay otro ingrediente o foto
    niaOpenAddExtraFlow();
  } catch (err) {
    console.error('Error al analizar agregado:', err);
    showMsg('Fallo al analizar el agregado: ' + err.message);
    if (loading) loading.classList.add('hidden');
    if (textBlock) textBlock.classList.remove('hidden');
  }
}

function niaRenderPhotosPreview() {
  const container = document.getElementById('photo-preview-container');
  if (!container) return;

  if (niaUploadedPhotos.length === 0) {
    container.innerHTML = `
      <img id="photo-preview-img" src="" alt="Vista previa de comida" />
      <button type="button" id="remove-photo-btn" class="remove-photo-btn" onclick="niaRemovePhoto(event)">×</button>
    `;
    return;
  }

  if (niaUploadedPhotos.length === 1) {
    container.innerHTML = `
      <img id="photo-preview-img" src="${niaUploadedPhotos[0].dataUrl}" alt="Vista previa de comida" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
      <button type="button" id="remove-photo-btn" class="remove-photo-btn" onclick="niaRemovePhoto(event)">×</button>
    `;
  } else if (niaUploadedPhotos.length === 2) {
    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: center; gap: 12px; width: 100%; height: 100%; padding: 12px; box-sizing: border-box; background: rgba(0,0,0,0.03);">
        <div style="flex: 1; height: 100%; border-radius: 8px; overflow: hidden; border: 1.5px solid rgba(200,29,58,0.15); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
          <img src="${niaUploadedPhotos[0].dataUrl}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
        </div>
        <span style="font-size: 2.2rem; font-weight: 700; color: var(--green); text-shadow: 0 1px 2px rgba(0,0,0,0.1); margin: 0 4px; z-index: 15;">+</span>
        <div style="flex: 1; height: 100%; border-radius: 8px; overflow: hidden; border: 1.5px solid rgba(200,29,58,0.15); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
          <img src="${niaUploadedPhotos[1].dataUrl}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
        </div>
      </div>
      <button type="button" id="remove-photo-btn" class="remove-photo-btn" onclick="niaRemovePhoto(event)">×</button>
    `;
  } else {
    // 3 or more photos
    container.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; height: 100%; padding: 8px; box-sizing: border-box; background: rgba(0,0,0,0.03);">
        <div style="flex: 1; height: 100%; border-radius: 8px; overflow: hidden; border: 1.5px solid rgba(200,29,58,0.15); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
          <img src="${niaUploadedPhotos[0].dataUrl}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
        </div>
        <span style="font-size: 1.6rem; font-weight: 700; color: var(--green); text-shadow: 0 1px 2px rgba(0,0,0,0.1); z-index: 15;">+</span>
        <div style="flex: 1; height: 100%; border-radius: 8px; overflow: hidden; border: 1.5px solid rgba(200,29,58,0.15); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
          <img src="${niaUploadedPhotos[1].dataUrl}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
        </div>
        <span style="font-size: 1.6rem; font-weight: 700; color: var(--green); text-shadow: 0 1px 2px rgba(0,0,0,0.1); z-index: 15;">+</span>
        <div style="flex: 1; height: 100%; border-radius: 8px; overflow: hidden; border: 1.5px solid rgba(200,29,58,0.15); box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
          <img src="${niaUploadedPhotos[2].dataUrl}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
        </div>
      </div>
      <button type="button" id="remove-photo-btn" class="remove-photo-btn" onclick="niaRemovePhoto(event)">×</button>
    `;
  }
}

// ===== INTEGRACIÓN DE APPS Y SMARTWATCHES =====
async function connectApp(appName, btn) {
  // Plan Básico check: Always redirect to premium upgrade dialog
  if (typeof openPremiumModal === 'function') {
    openPremiumModal(appName, btn);
    return;
  }

  const appLabels = {
    garmin: 'Garmin Connect', apple: 'Apple Health', google: 'Google Fit',
    fitbit: 'Fitbit', strava: 'Strava', polar: 'Polar Flow',
    samsung: 'Samsung Health', suunto: 'Suunto'
  };

  const isNative = typeof window !== 'undefined' && (window.cordova || window.Capacitor);

  if (isNative && (appName === 'apple' || appName === 'google' || appName === 'samsung')) {
    btn.textContent = 'Solicitando...';
    btn.disabled = true;

    if (!navigator.health) {
      btn.textContent = 'No disponible';
      showMsg('❌ Error: El plugin de salud no está cargado.');
      btn.disabled = false;
      return;
    }

    navigator.health.isAvailable(() => {
      // Solicitar permisos de lectura
      const dataTypes = ['steps', 'calories.active', 'distance', 'heart_rate', 'sleep'];
      navigator.health.requestAuthorization(dataTypes, async () => {
        btn.textContent = '✓ Conectado';
        btn.classList.add('connected');
        btn.disabled = true;
        showMsg(`✅ Sincronizado con ${appLabels[appName]}`);
        await importRealHealthData(appName);
      }, (err) => {
        console.error("Permiso denegado", err);
        btn.textContent = 'Conectar';
        btn.disabled = false;
        showMsg('❌ Permiso de salud denegado.');
      });
    }, (err) => {
      console.error("Servicio de salud no disponible", err);
      btn.textContent = 'No disponible';
      showMsg('❌ Las funciones de salud no están disponibles en este dispositivo.');
    });
  } else {
    // Si se trata de Garmin/Fitbit etc. en nativo, recordar que se sincronizan por el agregador
    if (isNative && appName !== 'apple' && appName !== 'google' && appName !== 'samsung') {
      showMsg(`ℹ️ Sincronizá tu reloj ${appLabels[appName]} con la app de Salud (Apple Health o Google Fit) y luego conéctala desde aquí.`);
      return;
    }

    // Simulación en PWA (Web)
    btn.textContent = 'Conectando...';
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = '✓ Conectado';
      btn.classList.add('connected');
      btn.disabled = true;
      showMsg(`✅ ${appLabels[appName]} (Simulación PWA) conectado`);
      setTimeout(() => importSimulatedData(appName), 800);
    }, 1800);
  }
}

async function importRealHealthData(source) {
  const sourceLabels = {
    apple: 'Apple Health',
    google: 'Google Fit',
    samsung: 'Samsung Health'
  };

  const todayMidnight = new Date();
  todayMidnight.setHours(0,0,0,0);
  const now = new Date();

  showMsg('📊 Consultando métricas en tu dispositivo...');

  try {
    // 1. Pasos (Aggregated)
    const steps = await new Promise((resolve) => {
      navigator.health.queryAggregated({
        startDate: todayMidnight,
        endDate: now,
        dataType: 'steps',
        bucket: 'day'
      }, (res) => {
        if (res && res.length > 0) resolve(res[0].value || 0);
        else resolve(0);
      }, () => resolve(0));
    });

    // 2. Calorías Activas (Aggregated)
    const kcal = await new Promise((resolve) => {
      navigator.health.queryAggregated({
        startDate: todayMidnight,
        endDate: now,
        dataType: 'calories.active',
        bucket: 'day'
      }, (res) => {
        if (res && res.length > 0) resolve(Math.round(res[0].value || 0));
        else resolve(0);
      }, () => resolve(0));
    });

    // 3. Distancia (Aggregated) en metros -> pasar a km
    const distMeters = await new Promise((resolve) => {
      navigator.health.queryAggregated({
        startDate: todayMidnight,
        endDate: now,
        dataType: 'distance',
        bucket: 'day'
      }, (res) => {
        if (res && res.length > 0) resolve(res[0].value || 0);
        else resolve(0);
      }, () => resolve(0));
    });
    const dist = distMeters > 0 ? parseFloat((distMeters / 1000).toFixed(2)) : 0;

    // 4. Ritmo Cardíaco (Últimas 100 mediciones de hoy, promedio)
    const hr = await new Promise((resolve) => {
      navigator.health.query({
        startDate: todayMidnight,
        endDate: now,
        dataType: 'heart_rate',
        limit: 100
      }, (res) => {
        if (res && res.length > 0) {
          let sum = 0;
          res.forEach(item => sum += item.value);
          resolve(Math.round(sum / res.length));
        } else resolve(null);
      }, () => resolve(null));
    });

    // 5. Sueño (Query de las últimas 24hs)
    const yesterdayMidnight = new Date();
    yesterdayMidnight.setDate(yesterdayMidnight.getDate() - 1);
    yesterdayMidnight.setHours(18, 0, 0, 0); // Desde las 6pm de ayer

    const sleep = await new Promise((resolve) => {
      navigator.health.query({
        startDate: yesterdayMidnight,
        endDate: now,
        dataType: 'sleep',
        limit: 50
      }, (res) => {
        if (res && res.length > 0) {
          let totalSleepMs = 0;
          res.forEach(item => {
            if (item.startDate && item.endDate) {
              totalSleepMs += (new Date(item.endDate) - new Date(item.startDate));
            }
          });
          const hours = (totalSleepMs / (1000 * 60 * 60));
          resolve(hours > 0 ? parseFloat(hours.toFixed(1)) : null);
        } else resolve(null);
      }, () => resolve(null));
    });

    const today = new Date();
    const entry = {
      id: Date.now(),
      date: today.toLocaleDateString('es-AR'),
      time: today.toLocaleTimeString('es-AR', { hour:'2-digit', minute:'2-digit' }),
      steps: steps > 0 ? steps : null,
      kcal: kcal > 0 ? kcal : null,
      dist: dist > 0 ? dist : null,
      duration: null,
      hr: hr,
      elevation: null,
      sleep: sleep,
      water: null,
      source: sourceLabels[source] || source
    };

    if (entry.steps || entry.kcal || entry.hr || entry.sleep) {
      metrics.unshift(entry);
      localStorage.setItem('nutriMetrics', JSON.stringify(metrics));
      renderMetricsHistory();
      if (typeof checkAchievements === 'function') checkAchievements();
      showMsg(`📊 Datos reales de ${sourceLabels[source]} cargados.`);
    } else {
      showMsg('⚠️ No se encontraron métricas hoy en tu app de salud.');
    }
  } catch (err) {
    console.error("Error al importar datos reales", err);
    showMsg('❌ Error al importar datos reales.');
  }
}

function importSimulatedData(source) {
  const sourceLabels = {
    garmin: 'Garmin', apple: 'Apple Health', google: 'Google Fit',
    fitbit: 'Fitbit', strava: 'Strava', polar: 'Polar Flow',
    samsung: 'Samsung Health', suunto: 'Suunto'
  };
  const today = new Date();
  const entry = {
    id: Date.now(),
    date: today.toLocaleDateString('es-AR'),
    time: today.toLocaleTimeString('es-AR', { hour:'2-digit', minute:'2-digit' }),
    steps: 7500 + Math.floor(Math.random() * 4000),
    kcal: 280 + Math.floor(Math.random() * 200),
    dist: (4 + Math.random() * 6).toFixed(1),
    duration: 35 + Math.floor(Math.random() * 40),
    hr: 118 + Math.floor(Math.random() * 30),
    elevation: Math.floor(Math.random() * 200),
    sleep: (6 + Math.random() * 2).toFixed(1),
    water: 1500 + Math.floor(Math.random() * 1000),
    source: sourceLabels[source] || source
  };
  metrics.unshift(entry);
  localStorage.setItem('nutriMetrics', JSON.stringify(metrics));
  renderMetricsHistory();
  if (typeof checkAchievements === 'function') checkAchievements();
  showMsg(`📊 Datos de ${sourceLabels[source]} importados (PWA)`);
}

function saveMetrics() {
  const dateEl = document.getElementById('metric-date');
  const timeEl = document.getElementById('metric-time');
  const steps = document.getElementById('metric-steps')?.value;
  const kcal = document.getElementById('metric-kcal')?.value;
  const dist = document.getElementById('metric-dist')?.value;
  const duration = document.getElementById('metric-duration')?.value;
  const hr = document.getElementById('metric-hr')?.value;
  const elevation = document.getElementById('metric-elevation')?.value;
  const sleep = document.getElementById('metric-sleep')?.value;
  const water = document.getElementById('metric-water')?.value;
  const source = document.getElementById('metric-source')?.value || 'manual';

  if (!steps && !kcal && !dist) {
    showMsg('Completá al menos un campo de métrica 📅');
    return;
  }

  const sourceLabels = { garmin:'Garmin', apple:'Apple Health', google:'Google Fit', fitbit:'Fitbit', strava:'Strava', polar:'Polar', samsung:'Samsung Health', suunto:'Suunto', manual:'Manual' };

  const entry = {
    id: Date.now(),
    date: dateEl?.value ? new Date(dateEl.value + 'T12:00:00').toLocaleDateString('es-AR') : new Date().toLocaleDateString('es-AR'),
    time: timeEl?.value || new Date().toLocaleTimeString('es-AR', {hour:'2-digit',minute:'2-digit'}),
    steps: steps ? parseInt(steps) : null,
    kcal: kcal ? parseInt(kcal) : null,
    dist: dist ? parseFloat(dist) : null,
    duration: duration ? parseInt(duration) : null,
    hr: hr ? parseInt(hr) : null,
    elevation: elevation ? parseInt(elevation) : null,
    sleep: sleep ? parseFloat(sleep) : null,
    water: water ? parseInt(water) : null,
    source: sourceLabels[source] || 'Manual'
  };

  metrics.unshift(entry);
  localStorage.setItem('nutriMetrics', JSON.stringify(metrics));

  // Reset form
  ['metric-steps','metric-kcal','metric-dist','metric-duration','metric-hr','metric-elevation','metric-sleep','metric-water'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });

  renderMetricsHistory();
  showMsg('✅ Métricas guardadas correctamente');
}

function renderMetricsHistory() {
  const container = document.getElementById('metrics-history');
  if (!container) return;
  if (metrics.length === 0) {
    container.innerHTML = '<p class="empty-note">No hay métricas cargadas aún. Conectá una app o cargá tus datos manualmente.</p>';
    return;
  }
  container.innerHTML = metrics.slice(0, 10).map(m => `
    <div class="metric-entry glass-card">
      <div class="metric-entry-header">
        <span class="metric-source-badge">${m.source}</span>
        <span class="metric-datetime">${m.date} ${m.time}</span>
        <button class="supp-delete" onclick="deleteMetric(${m.id})" title="Eliminar">🗑</button>
      </div>
      <div class="metric-chips">
        ${m.steps ? `<div class="metric-chip"><span class="mc-icon">🏃</span><span class="mc-val">${m.steps.toLocaleString('es-AR')}</span><span class="mc-lbl">pasos</span></div>` : ''}
        ${m.kcal ? `<div class="metric-chip"><span class="mc-icon">🔥</span><span class="mc-val">${m.kcal}</span><span class="mc-lbl">kcal</span></div>` : ''}
        ${m.dist ? `<div class="metric-chip"><span class="mc-icon">📍</span><span class="mc-val">${m.dist} km</span><span class="mc-lbl">distancia</span></div>` : ''}
        ${m.duration ? `<div class="metric-chip"><span class="mc-icon">⏱️</span><span class="mc-val">${m.duration} min</span><span class="mc-lbl">duración</span></div>` : ''}
        ${m.hr ? `<div class="metric-chip"><span class="mc-icon">❤️</span><span class="mc-val">${m.hr} lpm</span><span class="mc-lbl">FC prom</span></div>` : ''}
        ${m.sleep ? `<div class="metric-chip"><span class="mc-icon">😴</span><span class="mc-val">${m.sleep}h</span><span class="mc-lbl">sueño</span></div>` : ''}
        ${m.water ? `<div class="metric-chip"><span class="mc-icon">💧</span><span class="mc-val">${m.water} ml</span><span class="mc-lbl">hidrat.</span></div>` : ''}
        ${m.elevation ? `<div class="metric-chip"><span class="mc-icon">🏔️</span><span class="mc-val">${m.elevation} m</span><span class="mc-lbl">elevación</span></div>` : ''}
      </div>
    </div>
  `).join('');
}

function deleteMetric(id) {
  metrics = metrics.filter(m => m.id !== id);
  localStorage.setItem('nutriMetrics', JSON.stringify(metrics));
  renderMetricsHistory();
}

// Window bindings for HTML inline onclick handlers
window.finishOnboarding = finishOnboarding;
window.goToPersonalization = goToPersonalization;
window.goToSlide = goToSlide;
window.nextOnbStep = nextOnbStep;
window.nextSlide = nextSlide;
window.niaEditProfileFromOnboarding = niaEditProfileFromOnboarding;
window.requestCameraPermission = requestCameraPermission;
window.requestNotificationPermission = requestNotificationPermission;
window.resetApp = resetApp;
window.toggleGoalMultiple = toggleGoalMultiple;
window.validateStep2 = validateStep2;
window.validateStep3 = validateStep3;
window.toggleClinicalItem = toggleClinicalItem;
window.startNewUserExperience = startNewUserExperience;
window.niaSelectMealDay = niaSelectMealDay;
window.niaCancelMealsFlow = niaCancelMealsFlow;
window.niaCancelExtraFlow = niaCancelExtraFlow;
window.niaOpenAddExtraFlow = niaOpenAddExtraFlow;
window.niaAddToLog = niaAddToLog;
window.niaAddEditIngredientRow = niaAddEditIngredientRow;
window.niaSubmitConfirmedIngredients = niaSubmitConfirmedIngredients;
window.niaExtraSelectHasPhoto = niaExtraSelectHasPhoto;
window.niaAnalyzeExtraText = niaAnalyzeExtraText;
window.niaRemovePhoto = niaRemovePhoto;
window.niaShowCalendarSelector = niaShowCalendarSelector;
window.niaHideCalendarSelector = niaHideCalendarSelector;
window.niaStartFlow = niaStartFlow;
window.niaSaveSheetsConfig = niaSaveSheetsConfig;
window.niaToggleSheetsHelp = niaToggleSheetsHelp;
window.niaCopyAppsScriptCode = niaCopyAppsScriptCode;
window.niaDownloadPDFReport = niaDownloadPDFReport;
window.showScreen = showScreen;
window.connectApp = connectApp;
window.saveMetrics = saveMetrics;

// ===== ONBOARDING SUMMARY & PLAN FUNCTIONS =====
function showOnboardingSummary() {
    const calEl = document.getElementById('onb-sum-calories');
    const protEl = document.getElementById('onb-sum-protein');
    const carbEl = document.getElementById('onb-sum-carbs');
    const fatEl = document.getElementById('onb-sum-fats');
    
    // Defensa contra guiones / NaN
    if (!profile || isNaN(profile.targetCals) || !profile.targetCals) {
        const weight = +document.getElementById('user-weight')?.value || 70;
        const height = +document.getElementById('user-height')?.value || 165;
        const age = +document.getElementById('user-age')?.value || 30;
        const sex = document.getElementById('user-sex')?.value || 'F';
        const activity = document.getElementById('user-activity')?.value || 'moderado';
        
        const mult = { sedentario: 1.2, ligero: 1.375, moderado: 1.55, activo: 1.725, muyActivo: 1.9 };
        const bmr = sex === 'M' ? 10 * weight + 6.25 * height - 5 * age + 5 : 10 * weight + 6.25 * height - 5 * age - 161;
        const tdee = Math.round(bmr * (mult[activity] || 1.55));
        
        profile = profile || {};
        profile.targetCals = tdee;
        profile.prot = Math.round(weight * 1.9);
        profile.fat = Math.round(tdee * 0.28 / 9);
        profile.carb = Math.round((tdee - profile.prot * 4 - profile.fat * 9) / 4);
    }
    
    if (calEl) calEl.textContent = profile.targetCals || '2.000';
    if (protEl) protEl.textContent = profile.prot || '130';
    if (carbEl) carbEl.textContent = profile.carb || '180';
    if (fatEl) fatEl.textContent = profile.fat || '60';
    
    // Hide progress bar and all steps
    document.querySelectorAll('.onb-step').forEach(s => {
        s.classList.remove('active');
        s.classList.add('hidden');
    });
    
    // Show step 6 by adding active and removing hidden
    const step6 = document.getElementById('onb-step-6');
    if (step6) {
        step6.classList.remove('hidden');
        step6.classList.add('active');
    }
    
    const progressContainer = document.getElementById('onb-progress-container');
    if (progressContainer) progressContainer.classList.add('hidden');
}

function finishOnboardingAndNavigate(targetTab) {
    localStorage.setItem('niaFirstTimeTour', 'true');
    localStorage.setItem('nutriProfile', JSON.stringify(profile));
    
    // Sincronizar automáticamente con Supabase si el usuario está autenticado
    if (typeof niaSyncLocalToCloud === 'function' && localStorage.getItem('niaSaasToken')) {
        niaSyncLocalToCloud();
    }

    if (targetTab === 'hidratacion') {
        localStorage.setItem('niaScrollToHydration', 'true');
        targetTab = 'comidas';
    }
    localStorage.setItem('niaFinishRedirect', targetTab);
    initApp();
}

// ===== PERSISTENT DAILY PROGRESS BAR =====
function updateDailyProgressBar() {
    const today = new Date().toDateString();
    
    // 1. Calculate meals progress (25% per meal, max 50%)
    const mealsToday = Array.isArray(meals) ? meals.filter(m => m.date === today).length : 0;
    const mealsProgress = Math.min(2, mealsToday) * 25;
    
    // 2. Calculate activities progress (25% per activity, max 25%)
    const activitiesToday = Array.isArray(activities) ? activities.filter(a => a.date === today).length : 0;
    const activitiesProgress = Math.min(1, activitiesToday) * 25;
    
    // 3. Calculate hydration progress (25% per logging, max 25%)
    let waterTodayCount = 0;
    try {
        const getTodayStr = () => new Date().toISOString().split('T')[0];
        let hydrationLog = [];
        const hl = localStorage.getItem('nutriHydrationLog');
        if (hl) hydrationLog = JSON.parse(hl);
        waterTodayCount = Array.isArray(hydrationLog) ? hydrationLog.filter(h => h.date === getTodayStr()).length : 0;
    } catch (e) {
        console.warn('Error reading hydration logs for progress:', e);
    }
    const hydrationProgress = Math.min(1, waterTodayCount) * 25;
    
    // Total progress
    const totalProgress = Math.min(100, mealsProgress + activitiesProgress + hydrationProgress);
    
    // Update elements
    const fillEl = document.getElementById('header-progress-fill');
    const valEl = document.getElementById('header-progress-val');
    
    if (fillEl) fillEl.style.width = `${totalProgress}%`;
    if (valEl) valEl.textContent = `${totalProgress}%`;
}

window.showOnboardingSummary = showOnboardingSummary;
window.finishOnboardingAndNavigate = finishOnboardingAndNavigate;
window.updateDailyProgressBar = updateDailyProgressBar;
window.niaSelectMealDayFromPicker = niaSelectMealDayFromPicker;

